import { cn } from "@/lib/utils";
import { HTMLAttributes } from "react";

interface SkillBadgeProps extends HTMLAttributes<HTMLDivElement> {
  skill: string;
  color?: "blue" | "green" | "gold";
  selected?: boolean;
  clickable?: boolean;
  onSelectChange?: (selected: boolean) => void;
}

export function SkillBadge({
  skill,
  color = "blue",
  selected = false,
  clickable = false,
  onSelectChange,
  className,
  ...props
}: SkillBadgeProps) {
  const colorClasses = {
    blue: selected ? "text-[#00FFFF] border-[#00FFFF]" : "text-gray-300 border-gray-700 hover:border-[#00FFFF]",
    green: selected ? "text-[#39FF14] border-[#39FF14]" : "text-gray-300 border-gray-700 hover:border-[#39FF14]",
    gold: selected ? "text-[#FFD700] border-[#FFD700]" : "text-gray-300 border-gray-700 hover:border-[#FFD700]",
  };

  const handleClick = () => {
    if (clickable && onSelectChange) {
      onSelectChange(!selected);
    }
  };

  return (
    <div
      className={cn(
        "px-3 py-1 rounded-xl text-sm font-medium border",
        "bg-[rgba(19,25,38,0.8)]", 
        colorClasses[color],
        clickable && "cursor-pointer",
        selected && "shadow-[0_0_5px_rgba(0,255,255,0.5)]",
        className
      )}
      onClick={handleClick}
      {...props}
    >
      {skill}
    </div>
  );
}
