import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Home, Compass, Users, MessageSquare, Video, PlusCircle, Bell, Settings, LogOut } from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";
import { UserAvatar } from "@/components/user/user-avatar";

interface SidebarProps {
  className?: string;
}

export function Sidebar({ className }: SidebarProps) {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  const [isCollapsed, setIsCollapsed] = useState(false);

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const links = [
    { icon: Home, label: "Home", href: "/dashboard" },
    { icon: Compass, label: "Discover", href: "/discover" },
    { icon: Users, label: "Friends", href: "/friends" },
    { icon: MessageSquare, label: "Chat", href: "/chat", badge: 3 },
    { icon: Video, label: "Meetings", href: "/meetings" },
    { icon: PlusCircle, label: "Create Post", href: "/create-post" },
    { icon: Bell, label: "Notifications", href: "/notifications", badge: 5 },
    { icon: Settings, label: "Settings", href: "/settings" },
  ];

  const toggleSidebar = () => {
    setIsCollapsed(!isCollapsed);
  };

  return (
    <aside 
      className={cn(
        "border-r border-gray-800 h-full flex flex-col transition-all duration-300 bg-[#1A1A1A] bg-opacity-25 backdrop-blur-md",
        isCollapsed ? "w-20" : "w-64",
        className
      )}
      style={{
        backgroundImage: "linear-gradient(to bottom, rgba(26, 26, 26, 0.25), rgba(19, 25, 38, 0.25))",
        borderColor: "rgba(255, 255, 255, 0.05)"
      }}
    >
      <div className="p-4 border-b border-gray-800 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          {!isCollapsed && (
            <span className="font-poppins font-bold text-xl text-[#00FFFF]">NexaSkill</span>
          )}
          {isCollapsed && (
            <span className="font-poppins font-bold text-xl text-[#00FFFF]">NS</span>
          )}
        </div>
        <button 
          className="text-gray-400 hover:text-white"
          onClick={toggleSidebar}
        >
          {isCollapsed ? "→" : "←"}
        </button>
      </div>
      
      <nav className="flex-1 py-6 overflow-y-auto">
        <ul className="space-y-2 px-3">
          {links.map((link) => (
            <li key={link.href}>
              <Link href={link.href}>
                <a 
                  className={cn(
                    "flex items-center space-x-3 px-4 py-3 rounded-2xl group transition",
                    location === link.href
                      ? "bg-[#1A1A1A] text-[#00FFFF]"
                      : "text-gray-400 hover:text-white"
                  )}
                >
                  <link.icon 
                    className={cn(
                      "flex-shrink-0 transition-transform",
                      "group-hover:text-[#00FFFF] group-hover:-translate-y-0.5"
                    )} 
                    size={20}
                  />
                  {!isCollapsed && <span>{link.label}</span>}
                  {link.badge && (
                    <span className="w-6 h-6 rounded-full bg-[#00FFFF] text-black text-xs flex items-center justify-center ml-auto">
                      {link.badge}
                    </span>
                  )}
                </a>
              </Link>
            </li>
          ))}
          
          <li className="py-2 border-t border-gray-800 mt-4" />
          
          <li>
            <button
              onClick={handleLogout}
              className="w-full flex items-center space-x-3 px-4 py-3 rounded-2xl text-gray-400 hover:text-white group transition"
            >
              <LogOut
                className="flex-shrink-0 group-hover:text-[#00FFFF] group-hover:-translate-y-0.5 transition-transform"
                size={20}
              />
              {!isCollapsed && <span>Logout</span>}
            </button>
          </li>
        </ul>
      </nav>
      
      {user && (
        <div className="p-4 border-t border-gray-800">
          <Link href="/profile">
            <a className="flex items-center space-x-3 px-3 py-2">
              <UserAvatar user={user} />
              {!isCollapsed && (
                <div>
                  <p className="text-sm font-medium">{user.firstName || user.username}</p>
                  <p className="text-xs text-gray-400">@{user.username}</p>
                </div>
              )}
            </a>
          </Link>
        </div>
      )}
    </aside>
  );
}
