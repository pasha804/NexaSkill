import { ReactNode, useState } from "react";
import { Search, Bell, MessageSquare } from "lucide-react";
import { cn } from "@/lib/utils";
import { Sidebar } from "./sidebar";
import { SkillBadge } from "@/components/ui/skill-badge";
import { useAuth } from "@/hooks/use-auth";

interface MainLayoutProps {
  children: ReactNode;
}

export function MainLayout({ children }: MainLayoutProps) {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");

  return (
    <div className="flex h-screen overflow-hidden bg-[#0D0D0D] text-white">
      <Sidebar />
      
      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        {/* Top Navigation */}
        <header className="h-16 border-b border-gray-800 flex items-center justify-between px-4 md:px-6 bg-[#1A1A1A] bg-opacity-25 backdrop-blur-md">
          <div className="relative w-full max-w-md">
            <input
              type="text"
              placeholder="Search skills, people, or posts..."
              className="w-full pl-10 pr-4 py-2 bg-[#131926] rounded-xl border border-gray-700 focus:border-[#00FFFF] focus:outline-none"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
          </div>
          
          <div className="flex items-center space-x-5">
            <button className="text-gray-400 hover:text-[#00FFFF] transition-colors">
              <Bell size={20} />
            </button>
            <button className="text-gray-400 hover:text-[#00FFFF] transition-colors">
              <MessageSquare size={20} />
            </button>
            <span className="md:flex items-center space-x-2 hidden">
              <span className="text-xl">👨‍💻</span>
              {user?.skills && user.skills[0] && (
                <SkillBadge skill={user.skills[0]} color="blue" />
              )}
            </span>
          </div>
        </header>

        {/* Content Area */}
        <div 
          className="flex-1 overflow-y-auto p-4 md:p-6 bg-gradient-to-b from-[#0D0D0D] to-[#131926]"
          style={{scrollbarWidth: 'thin'}}
        >
          {children}
        </div>
      </main>
    </div>
  );
}
