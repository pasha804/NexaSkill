import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { User } from "@shared/schema";

interface UserAvatarProps {
  user: User;
  size?: "sm" | "md" | "lg";
  className?: string;
}

export function UserAvatar({ user, size = "md", className }: UserAvatarProps) {
  // Calculate initials from username or first/last name
  const getInitials = () => {
    if (user.firstName && user.lastName) {
      return `${user.firstName[0]}${user.lastName[0]}`.toUpperCase();
    }
    if (user.firstName) {
      return user.firstName[0].toUpperCase();
    }
    if (user.username) {
      return user.username[0].toUpperCase();
    }
    return "U";
  };

  // Define size classes
  const sizeClasses = {
    sm: "h-8 w-8",
    md: "h-10 w-10",
    lg: "h-16 w-16",
  };

  // Generate a specific color based on the username for the avatar background
  const getUserColor = () => {
    const colors = [
      "from-[#00FFFF] to-[#131926]",
      "from-[#39FF14] to-[#131926]",
      "from-[#FFD700] to-[#131926]",
      "from-purple-500 to-[#131926]",
      "from-pink-500 to-[#131926]",
    ];
    
    // Use the username to deterministically select a color
    const hash = user.username.split("").reduce((acc, char) => {
      return acc + char.charCodeAt(0);
    }, 0);
    
    return colors[hash % colors.length];
  };

  return (
    <Avatar className={`${sizeClasses[size]} ${className}`}>
      <AvatarImage src={user.profileImage} alt={user.username} />
      <AvatarFallback 
        className={`bg-gradient-to-br ${getUserColor()} text-white font-medium`}
      >
        {getInitials()}
      </AvatarFallback>
    </Avatar>
  );
}
