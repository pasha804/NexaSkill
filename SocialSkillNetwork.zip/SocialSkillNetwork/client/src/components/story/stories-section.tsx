import { useState } from "react";
import { motion } from "framer-motion";
import { Plus, ChevronLeft, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { UserAvatar } from "@/components/user/user-avatar";
import { User } from "@shared/schema";

interface Story {
  id: number;
  user: User;
}

interface StoriesSectionProps {
  stories: Story[];
  currentUser: User;
  className?: string;
}

export function StoriesSection({ stories, currentUser, className }: StoriesSectionProps) {
  const [scrollPosition, setScrollPosition] = useState(0);
  const [showLeftArrow, setShowLeftArrow] = useState(false);
  const [showRightArrow, setShowRightArrow] = useState(true);

  const handleScroll = (direction: "left" | "right") => {
    const container = document.getElementById("stories-container");
    if (!container) return;

    const scrollAmount = 200; // Adjust as needed
    const newPosition = direction === "left" 
      ? scrollPosition - scrollAmount 
      : scrollPosition + scrollAmount;
    
    container.scrollTo({
      left: newPosition,
      behavior: "smooth"
    });
    
    setScrollPosition(newPosition);
    setShowLeftArrow(newPosition > 0);
    setShowRightArrow(newPosition < container.scrollWidth - container.clientWidth);
  };

  return (
    <div className={cn("relative", className)}>
      <h2 className="font-poppins font-semibold text-xl mb-4">Stories</h2>
      
      {showLeftArrow && (
        <button 
          className="absolute left-0 top-1/2 transform -translate-y-1/2 bg-[#1A1A1A] bg-opacity-70 rounded-full p-1 z-10"
          onClick={() => handleScroll("left")}
        >
          <ChevronLeft className="text-white" size={20} />
        </button>
      )}
      
      {showRightArrow && (
        <button 
          className="absolute right-0 top-1/2 transform -translate-y-1/2 bg-[#1A1A1A] bg-opacity-70 rounded-full p-1 z-10"
          onClick={() => handleScroll("right")}
        >
          <ChevronRight className="text-white" size={20} />
        </button>
      )}
      
      <div 
        id="stories-container"
        className="flex space-x-4 overflow-x-auto pb-4 scrollbar-hide"
        style={{ scrollbarWidth: "none" }}
        onScroll={(e) => {
          const target = e.target as HTMLDivElement;
          setScrollPosition(target.scrollLeft);
          setShowLeftArrow(target.scrollLeft > 0);
          setShowRightArrow(
            target.scrollLeft < target.scrollWidth - target.clientWidth
          );
        }}
      >
        {/* Your Story */}
        <motion.div 
          className="flex flex-col items-center flex-shrink-0"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <div 
            className="mb-1 cursor-pointer"
            style={{
              background: "linear-gradient(45deg, #00FFFF, #39FF14)",
              padding: "2px",
              borderRadius: "9999px",
            }}
          >
            <div className="w-16 h-16 bg-[#131926] rounded-full flex items-center justify-center">
              <Plus className="text-[#00FFFF]" size={24} />
            </div>
          </div>
          <span className="text-xs text-gray-300">Add Story</span>
        </motion.div>
        
        {/* Other Stories */}
        {stories.map((story, index) => (
          <motion.div 
            key={story.id}
            className="flex flex-col items-center flex-shrink-0"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.05 * (index + 1) }}
          >
            <div 
              className="mb-1 cursor-pointer"
              style={{
                background: "linear-gradient(45deg, #00FFFF, #39FF14)",
                padding: "2px",
                borderRadius: "9999px",
              }}
            >
              <div className="w-16 h-16 rounded-full overflow-hidden">
                <UserAvatar user={story.user} size="lg" />
              </div>
            </div>
            <span className="text-xs text-gray-300">
              {story.user.firstName || story.user.username.split("_")[0]}
            </span>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
