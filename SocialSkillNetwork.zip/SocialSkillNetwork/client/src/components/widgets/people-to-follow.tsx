import { motion } from "framer-motion";
import { ChevronRight } from "lucide-react";
import { UserAvatar } from "@/components/user/user-avatar";

// Mock people to follow data
const peopleToFollowData = [
  { 
    id: 1, 
    firstName: "Emma", 
    lastName: "Wilson", 
    username: "emma_data", 
    profession: "Data Scientist" 
  },
  { 
    id: 2, 
    firstName: "Michael", 
    lastName: "Chen", 
    username: "mike_dev", 
    profession: "Frontend Developer" 
  },
  { 
    id: 3, 
    firstName: "Jessica", 
    lastName: "Kim", 
    username: "jess_design", 
    profession: "UX Designer" 
  }
];

export function PeopleToFollow() {
  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0, y: 10 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.3,
        delay: 0.1,
        staggerChildren: 0.1
      }
    }
  };
  
  const itemVariants = {
    hidden: { opacity: 0, y: 10 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.2 }
    }
  };

  return (
    <motion.div 
      className="rounded-3xl p-5 bg-[#1A1A1A] bg-opacity-25 backdrop-blur-md border border-gray-800"
      style={{
        backgroundImage: "linear-gradient(to bottom, rgba(26, 26, 26, 0.25), rgba(19, 25, 38, 0.25))",
        borderColor: "rgba(255, 255, 255, 0.05)",
        boxShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)"
      }}
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      <h3 className="font-poppins font-semibold text-lg mb-4">People to Follow</h3>
      <ul className="space-y-4">
        {peopleToFollowData.map((person) => (
          <motion.li 
            key={person.id} 
            className="flex justify-between items-center"
            variants={itemVariants}
          >
            <div className="flex items-center space-x-3">
              <UserAvatar 
                user={{ 
                  id: person.id, 
                  username: person.username,
                  firstName: person.firstName,
                  lastName: person.lastName,
                  password: ""
                }} 
              />
              <div>
                <p className="font-medium text-white">{person.firstName} {person.lastName}</p>
                <p className="text-xs text-gray-400">{person.profession}</p>
              </div>
            </div>
            <button className="px-3 py-1 rounded-lg border border-[#00FFFF] text-xs text-[#00FFFF] hover:bg-[#00FFFF] hover:bg-opacity-10 transition-colors">
              Follow
            </button>
          </motion.li>
        ))}
      </ul>
      <motion.button 
        className="w-full mt-4 py-2 rounded-xl text-sm text-[#00FFFF] hover:text-white transition-colors flex items-center justify-center"
        variants={itemVariants}
      >
        <span>View more</span>
        <ChevronRight size={16} className="ml-1" />
      </motion.button>
    </motion.div>
  );
}
