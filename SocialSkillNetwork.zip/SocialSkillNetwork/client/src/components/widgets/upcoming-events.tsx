import { motion } from "framer-motion";
import { Calendar, ChevronRight } from "lucide-react";
import { UserAvatar } from "@/components/user/user-avatar";

// Mock upcoming events data
const upcomingEventsData = [
  {
    id: 1,
    title: "React Meetup",
    date: { month: "OCT", day: "15" },
    location: "Online",
    time: "7:00 PM",
    attendees: [
      { id: 1, username: "sarah_dev", firstName: "Sarah", lastName: "Lin" },
      { id: 2, username: "mike_code", firstName: "Mike", lastName: "Thompson" },
      { id: 3, username: "dev_alex", firstName: "Alex", lastName: "Morgan" }
    ],
    totalAttendees: 11
  },
  {
    id: 2,
    title: "AI Workshop",
    date: { month: "OCT", day: "22" },
    location: "Virtual",
    time: "2:00 PM",
    attendees: [
      { id: 4, username: "jess_ai", firstName: "Jessica", lastName: "Kim" },
      { id: 5, username: "james_ml", firstName: "James", lastName: "Donovan" }
    ],
    totalAttendees: 7
  }
];

export function UpcomingEvents() {
  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0, y: 10 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.3,
        delay: 0.2,
        staggerChildren: 0.1
      }
    }
  };
  
  const itemVariants = {
    hidden: { opacity: 0, y: 10 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.2 }
    }
  };

  return (
    <motion.div 
      className="rounded-3xl p-5 bg-[#1A1A1A] bg-opacity-25 backdrop-blur-md border border-gray-800"
      style={{
        backgroundImage: "linear-gradient(to bottom, rgba(26, 26, 26, 0.25), rgba(19, 25, 38, 0.25))",
        borderColor: "rgba(255, 255, 255, 0.05)",
        boxShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)"
      }}
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      <h3 className="font-poppins font-semibold text-lg mb-4">Upcoming Events</h3>
      <div className="space-y-3">
        {upcomingEventsData.map((event) => (
          <motion.div 
            key={event.id}
            className="rounded-2xl p-3 bg-[#131926]"
            variants={itemVariants}
          >
            <div className="flex items-center space-x-3 mb-2">
              <div className={`w-12 h-12 rounded-xl ${event.id % 2 === 0 ? 'bg-[#39FF14]' : 'bg-[#00FFFF]'} bg-opacity-20 flex flex-col items-center justify-center ${event.id % 2 === 0 ? 'text-[#39FF14]' : 'text-[#00FFFF]'}`}>
                <span className="text-xs">{event.date.month}</span>
                <span className="font-bold">{event.date.day}</span>
              </div>
              <div>
                <p className="font-medium text-white">{event.title}</p>
                <p className="text-xs text-gray-400">{event.location} • {event.time}</p>
              </div>
            </div>
            <div className="flex items-center">
              <div className="flex -space-x-2">
                {event.attendees.map((attendee, index) => (
                  <UserAvatar 
                    key={index}
                    user={{ 
                      id: attendee.id, 
                      username: attendee.username,
                      firstName: attendee.firstName,
                      lastName: attendee.lastName,
                      password: ""
                    }}
                    size="sm"
                    className="border border-[#131926]"
                  />
                ))}
                <span className="w-6 h-6 rounded-full bg-[#1A1A1A] border border-[#131926] flex items-center justify-center text-xs text-gray-400">
                  +{event.totalAttendees - event.attendees.length}
                </span>
              </div>
              <button className="ml-auto p-1 rounded-lg text-gray-400 hover:text-[#00FFFF] transition-colors">
                <Calendar size={16} />
              </button>
            </div>
          </motion.div>
        ))}
      </div>
      <motion.button 
        className="w-full mt-4 py-2 rounded-xl text-sm text-[#00FFFF] hover:text-white transition-colors flex items-center justify-center"
        variants={itemVariants}
      >
        <span>View all events</span>
        <ChevronRight size={16} className="ml-1" />
      </motion.button>
    </motion.div>
  );
}
