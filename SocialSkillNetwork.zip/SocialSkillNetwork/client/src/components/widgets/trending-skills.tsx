import { motion } from "framer-motion";
import { ChevronRight } from "lucide-react";

// Trending skills data with percentage increase
const trendingSkillsData = [
  { name: "React.js", icon: "code", percentage: "+12%", color: "electric-blue" },
  { name: "Machine Learning", icon: "robot", percentage: "+24%", color: "neon-green" },
  { name: "Blockchain", icon: "cube", percentage: "+18%", color: "metallic-gold" },
  { name: "Flutter", icon: "mobile-alt", percentage: "+10%", color: "electric-blue" },
  { name: "AWS", icon: "server", percentage: "+15%", color: "neon-green" }
];

export function TrendingSkills() {
  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0, y: 10 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.3,
        staggerChildren: 0.1
      }
    }
  };
  
  const itemVariants = {
    hidden: { opacity: 0, y: 10 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.2 }
    }
  };

  // Get icon element based on icon name and color
  const getIconElement = (icon: string, color: string) => {
    const iconClass = `fas fa-${icon}`;
    const bgColorClass = color === "electric-blue" 
      ? "bg-[#00FFFF] bg-opacity-20 text-[#00FFFF]" 
      : color === "neon-green" 
        ? "bg-[#39FF14] bg-opacity-20 text-[#39FF14]" 
        : "bg-[#FFD700] bg-opacity-20 text-[#FFD700]";
    
    return (
      <span className={`w-8 h-8 rounded-lg ${bgColorClass} flex items-center justify-center`}>
        <i className={iconClass}></i>
      </span>
    );
  };

  return (
    <motion.div 
      className="rounded-3xl p-5 bg-[#1A1A1A] bg-opacity-25 backdrop-blur-md border border-gray-800"
      style={{
        backgroundImage: "linear-gradient(to bottom, rgba(26, 26, 26, 0.25), rgba(19, 25, 38, 0.25))",
        borderColor: "rgba(255, 255, 255, 0.05)",
        boxShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)"
      }}
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      <h3 className="font-poppins font-semibold text-lg mb-4">Trending Skills</h3>
      <ul className="space-y-3">
        {trendingSkillsData.map((skill, index) => (
          <motion.li 
            key={index} 
            className="flex justify-between items-center"
            variants={itemVariants}
          >
            <div className="flex items-center space-x-2">
              {getIconElement(skill.icon, skill.color)}
              <span>{skill.name}</span>
            </div>
            <span className="text-xs text-gray-400">{skill.percentage}</span>
          </motion.li>
        ))}
      </ul>
      <motion.button 
        className="w-full mt-4 py-2 rounded-xl text-sm text-[#00FFFF] hover:text-white transition-colors flex items-center justify-center"
        variants={itemVariants}
      >
        <span>See all trends</span>
        <ChevronRight size={16} className="ml-1" />
      </motion.button>
    </motion.div>
  );
}
