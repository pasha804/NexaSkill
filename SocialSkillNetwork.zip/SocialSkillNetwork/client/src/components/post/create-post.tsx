import { useState } from "react";
import { Image, Video, Code, Send } from "lucide-react";
import { motion } from "framer-motion";
import { useMutation } from "@tanstack/react-query";
import { cn } from "@/lib/utils";
import { UserAvatar } from "@/components/user/user-avatar";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { InsertPost } from "@shared/schema";

interface CreatePostProps {
  className?: string;
}

export function CreatePost({ className }: CreatePostProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [content, setContent] = useState("");
  const [image, setImage] = useState<string | null>(null);
  const [skills, setSkills] = useState<string[]>([]);
  const [showSkillsInput, setShowSkillsInput] = useState(false);
  const [skillInput, setSkillInput] = useState("");

  const createPostMutation = useMutation({
    mutationFn: async (postData: InsertPost) => {
      const res = await apiRequest("POST", "/api/posts", postData);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Post created",
        description: "Your post has been published successfully!",
      });
      setContent("");
      setImage(null);
      setSkills([]);
      setShowSkillsInput(false);
      // Invalidate posts query to refetch the latest posts
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
    },
    onError: (error) => {
      toast({
        title: "Failed to create post",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = () => {
    if (!content.trim()) {
      toast({
        title: "Post cannot be empty",
        description: "Please add some content to your post",
        variant: "destructive",
      });
      return;
    }

    createPostMutation.mutate({
      content,
      image: image || undefined,
      skills: skills.length ? skills : undefined,
    });
  };

  const handleSkillAdd = () => {
    if (skillInput.trim() && !skills.includes(skillInput.trim())) {
      setSkills([...skills, skillInput.trim()]);
      setSkillInput("");
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && skillInput.trim()) {
      e.preventDefault();
      handleSkillAdd();
    }
  };

  const removeSkill = (skillToRemove: string) => {
    setSkills(skills.filter(skill => skill !== skillToRemove));
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={cn(
        "rounded-3xl p-4 bg-[#1A1A1A] bg-opacity-25 backdrop-blur-md border border-gray-800",
        "hover:border-gray-700 transition-colors",
        className
      )}
      style={{
        backgroundImage: "linear-gradient(to bottom, rgba(26, 26, 26, 0.25), rgba(19, 25, 38, 0.25))",
        borderColor: "rgba(255, 255, 255, 0.05)",
        boxShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)"
      }}
    >
      <div className="flex space-x-3">
        <UserAvatar user={user!} />
        <textarea
          placeholder="Share your skills or ask for collaboration..."
          className="w-full px-4 py-2 bg-[#131926] rounded-xl border border-gray-700 focus:border-[#00FFFF] focus:outline-none resize-none"
          rows={2}
          value={content}
          onChange={(e) => setContent(e.target.value)}
        />
      </div>

      {image && (
        <div className="mt-3 relative">
          <img src={image} alt="Post preview" className="rounded-xl w-full max-h-60 object-cover" />
          <button 
            className="absolute top-2 right-2 bg-black bg-opacity-50 rounded-full p-1 text-white"
            onClick={() => setImage(null)}
          >
            ✕
          </button>
        </div>
      )}

      {showSkillsInput && (
        <div className="mt-3">
          <div className="flex space-x-2 mb-2">
            {skills.map((skill, index) => (
              <div key={index} className="flex items-center bg-[#131926] rounded-lg px-2 py-1">
                <span className="text-sm text-[#00FFFF]">{skill}</span>
                <button 
                  className="ml-2 text-gray-400 hover:text-white"
                  onClick={() => removeSkill(skill)}
                >
                  ✕
                </button>
              </div>
            ))}
          </div>
          <div className="flex">
            <input
              type="text"
              placeholder="Add skill tags..."
              className="flex-1 px-3 py-2 bg-[#131926] rounded-l-lg border border-gray-700 focus:border-[#00FFFF] focus:outline-none text-sm"
              value={skillInput}
              onChange={(e) => setSkillInput(e.target.value)}
              onKeyDown={handleKeyDown}
            />
            <button
              className="bg-[#00FFFF] text-black px-3 py-2 rounded-r-lg text-sm font-medium"
              onClick={handleSkillAdd}
            >
              Add
            </button>
          </div>
        </div>
      )}
      
      <div className="flex mt-3 pt-3 border-t border-gray-800 justify-between">
        <div className="flex space-x-4">
          <button className="flex items-center space-x-2 text-gray-400 hover:text-[#00FFFF] transition-colors">
            <Image size={18} />
            <span className="text-sm hidden md:inline">Photo</span>
          </button>
          <button className="flex items-center space-x-2 text-gray-400 hover:text-[#00FFFF] transition-colors">
            <Video size={18} />
            <span className="text-sm hidden md:inline">Video</span>
          </button>
          <button 
            className="flex items-center space-x-2 text-gray-400 hover:text-[#00FFFF] transition-colors"
            onClick={() => setShowSkillsInput(!showSkillsInput)}
          >
            <Code size={18} />
            <span className="text-sm hidden md:inline">Skills</span>
          </button>
        </div>
        <button 
          className="px-4 py-1 rounded-xl bg-gradient-to-r from-[#00FFFF] to-[#39FF14] text-black text-sm font-medium hover:opacity-90 transition-opacity flex items-center space-x-1"
          onClick={handleSubmit}
          disabled={createPostMutation.isPending}
        >
          {createPostMutation.isPending ? (
            <span>Posting...</span>
          ) : (
            <>
              <Send size={14} />
              <span>Post</span>
            </>
          )}
        </button>
      </div>
    </motion.div>
  );
}
