import { useState } from "react";
import { Heart, MessageSquare, Share, Bookmark } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { UserAvatar } from "@/components/user/user-avatar";
import { SkillBadge } from "@/components/ui/skill-badge";
import { User, Post } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";

interface PostCardProps {
  post: Post;
  user: User;
  className?: string;
}

export function PostCard({ post, user, className }: PostCardProps) {
  const [isLiked, setIsLiked] = useState(false);
  const [likesCount, setLikesCount] = useState(post.likes || 0);
  const [isSaved, setIsSaved] = useState(false);

  const handleLike = () => {
    if (isLiked) {
      setLikesCount(likesCount - 1);
    } else {
      setLikesCount(likesCount + 1);
    }
    setIsLiked(!isLiked);
    // Here you would call an API to save the like status
  };

  const handleSave = () => {
    setIsSaved(!isSaved);
    // Here you would call an API to save the bookmark status
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className={cn(
        "rounded-3xl p-5 bg-[#1A1A1A] bg-opacity-25 backdrop-blur-md border border-gray-800",
        "hover:border-gray-700 transition-colors",
        className
      )}
      style={{
        backgroundImage: "linear-gradient(to bottom, rgba(26, 26, 26, 0.25), rgba(19, 25, 38, 0.25))",
        borderColor: "rgba(255, 255, 255, 0.05)",
        boxShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)"
      }}
    >
      <div className="flex justify-between items-start mb-4">
        <div className="flex space-x-3">
          <UserAvatar user={user} />
          <div>
            <p className="font-medium">
              {user.firstName} {user.lastName}{" "}
              <span className="text-xs text-gray-400">@{user.username}</span>
            </p>
            <p className="text-xs text-gray-400">
              {post.createdAt 
                ? formatDistanceToNow(new Date(post.createdAt), { addSuffix: true }) 
                : "recently"}
            </p>
          </div>
        </div>
        <div className="flex space-x-1">
          {post.skills && post.skills.map((skill, index) => (
            <SkillBadge 
              key={index} 
              skill={skill} 
              color={index % 3 === 0 ? "blue" : index % 3 === 1 ? "green" : "gold"} 
            />
          ))}
        </div>
      </div>
      
      <div className="mb-4">
        <p className="mb-3">{post.content}</p>
        {post.image && (
          <div className="rounded-2xl overflow-hidden mt-3">
            <img 
              src={post.image} 
              alt="Post content" 
              className="w-full object-cover" 
            />
          </div>
        )}
      </div>
      
      <div className="flex justify-between items-center pt-3 border-t border-gray-800">
        <div className="flex space-x-4">
          <button 
            className={cn(
              "flex items-center space-x-1 hover:text-[#00FFFF] transition-colors",
              isLiked ? "text-[#00FFFF]" : "text-gray-400"
            )}
            onClick={handleLike}
          >
            <Heart size={18} className={isLiked ? "fill-[#00FFFF]" : ""} />
            <span>{likesCount}</span>
          </button>
          <button className="flex items-center space-x-1 text-gray-400 hover:text-[#00FFFF] transition-colors">
            <MessageSquare size={18} />
            <span>{post.comments}</span>
          </button>
          <button className="flex items-center space-x-1 text-gray-400 hover:text-[#00FFFF] transition-colors">
            <Share size={18} />
            <span>{post.shares}</span>
          </button>
        </div>
        <button 
          className={cn(
            "transition-colors",
            isSaved ? "text-[#00FFFF]" : "text-gray-400 hover:text-[#00FFFF]"
          )}
          onClick={handleSave}
        >
          <Bookmark size={18} className={isSaved ? "fill-[#00FFFF]" : ""} />
        </button>
      </div>
    </motion.div>
  );
}
