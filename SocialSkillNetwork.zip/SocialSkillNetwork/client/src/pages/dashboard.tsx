import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { MainLayout } from "@/components/layout/main-layout";
import { StoriesSection } from "@/components/story/stories-section";
import { CreatePost } from "@/components/post/create-post";
import { PostCard } from "@/components/post/post-card";
import { TrendingSkills } from "@/components/widgets/trending-skills";
import { PeopleToFollow } from "@/components/widgets/people-to-follow";
import { UpcomingEvents } from "@/components/widgets/upcoming-events";
import { useAuth } from "@/hooks/use-auth";
import { Post, User } from "@shared/schema";
import { Loader2 } from "lucide-react";

export default function Dashboard() {
  const { user } = useAuth();
  
  // Fetch posts
  const { 
    data: posts, 
    isLoading: postsLoading,
    error: postsError
  } = useQuery<Post[]>({
    queryKey: ["/api/posts"],
  });

  // Mock stories data
  const storyUsers = [
    { id: 1, user: { id: 2, username: "sarah_l", firstName: "Sarah", lastName: "Lin" } },
    { id: 2, user: { id: 3, username: "mike_t", firstName: "Mike", lastName: "Thompson" } },
    { id: 3, user: { id: 4, username: "jessica_k", firstName: "Jessica", lastName: "Kim" } },
    { id: 4, user: { id: 5, username: "robert_p", firstName: "Robert", lastName: "Patel" } },
    { id: 5, user: { id: 6, username: "james_d", firstName: "James", lastName: "Donovan" } }
  ];

  // Mock user data for posts
  const getUserForPost = (userId: number): User => {
    // Default user in case we don't have data
    return {
      id: userId,
      username: "user" + userId,
      password: "",
      firstName: "User",
      lastName: "" + userId,
      createdAt: new Date()
    };
  };

  if (!user) {
    return null; // Protected route should handle this
  }

  return (
    <MainLayout>
      <div className="max-w-screen-xl mx-auto">
        {/* Stories Section */}
        <StoriesSection 
          stories={storyUsers}
          currentUser={user}
          className="mb-8"
        />
        
        {/* Two Column Layout */}
        <div className="grid md:grid-cols-3 gap-6">
          {/* Left Column (Feed) */}
          <div className="md:col-span-2 space-y-6">
            {/* Create Post Card */}
            <CreatePost />
            
            {/* Feed Posts */}
            <div className="space-y-6">
              {postsLoading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-[#00FFFF]" />
                </div>
              ) : postsError ? (
                <div className="text-center py-8">
                  <p className="text-red-500">Failed to load posts</p>
                </div>
              ) : posts && posts.length > 0 ? (
                posts.map((post) => (
                  <PostCard 
                    key={post.id} 
                    post={post} 
                    user={getUserForPost(post.userId)}
                  />
                ))
              ) : (
                <div className="text-center py-8 bg-[#1A1A1A] bg-opacity-25 backdrop-blur-md rounded-3xl p-6 border border-gray-800">
                  <p className="text-gray-400 mb-4">No posts yet</p>
                  <p className="text-sm text-gray-500">Be the first to share something with the community!</p>
                </div>
              )}
            </div>
          </div>
          
          {/* Right Column (Widgets) */}
          <div className="space-y-6">
            <TrendingSkills />
            <PeopleToFollow />
            <UpcomingEvents />
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
