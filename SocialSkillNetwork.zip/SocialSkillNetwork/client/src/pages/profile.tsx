import { useState } from "react";
import { useParams, Link } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Edit, UserPlus, UserCheck, Mail, Share, Grid, List, Bookmark } from "lucide-react";
import { MainLayout } from "@/components/layout/main-layout";
import { SkillBadge } from "@/components/ui/skill-badge";
import { PostCard } from "@/components/post/post-card";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { User, Post } from "@shared/schema";
import { Loader2 } from "lucide-react";

export default function Profile() {
  const { username } = useParams();
  const { user: currentUser } = useAuth();
  const [viewMode, setViewMode] = useState<"grid" | "list">("list");
  
  // Get profile for username or current user
  const {
    data: profileUser,
    isLoading: profileLoading,
    error: profileError
  } = useQuery<User>({
    queryKey: [username ? `/api/users/${username}` : `/api/user`],
  });

  // Get posts for profile
  const {
    data: posts,
    isLoading: postsLoading,
    error: postsError
  } = useQuery<Post[]>({
    queryKey: [username ? `/api/users/${username}/posts` : `/api/posts`],
    enabled: !!profileUser,
  });

  // Send friend request
  const friendRequestMutation = useMutation({
    mutationFn: async (userId: number) => {
      const res = await apiRequest("POST", `/api/friends/${userId}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/friends"] });
    }
  });

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.3 }
    }
  };

  // Check if this is the current user's profile
  const isOwnProfile = !username || (currentUser && profileUser && currentUser.id === profileUser.id);

  if (profileLoading) {
    return (
      <MainLayout>
        <div className="flex justify-center items-center py-20">
          <Loader2 className="h-10 w-10 animate-spin text-[#00FFFF]" />
        </div>
      </MainLayout>
    );
  }

  if (profileError || !profileUser) {
    return (
      <MainLayout>
        <div className="max-w-screen-xl mx-auto">
          <div className="text-center py-20 bg-[#1A1A1A] bg-opacity-25 backdrop-blur-md rounded-3xl p-6 border border-gray-800">
            <h2 className="text-xl font-medium text-white mb-2">Profile Not Found</h2>
            <p className="text-gray-400 mb-6">
              The user profile you're looking for doesn't exist or isn't accessible.
            </p>
            <Link href="/dashboard">
              <a className="px-5 py-2 rounded-xl bg-[#00FFFF] text-black font-medium hover:opacity-90 transition-opacity">
                Return to Dashboard
              </a>
            </Link>
          </div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="max-w-screen-xl mx-auto">
        <motion.div
          initial="hidden"
          animate="visible"
          variants={containerVariants}
        >
          {/* Profile Header */}
          <motion.div 
            className="mb-8 bg-[#1A1A1A] bg-opacity-25 backdrop-blur-md rounded-3xl overflow-hidden border border-gray-800"
            variants={itemVariants}
          >
            {/* Cover Image */}
            <div 
              className="h-48 bg-gradient-to-r from-[#131926] to-[#1A1A1A] relative"
              style={{ 
                backgroundImage: "linear-gradient(to right, #131926, #1a1a1a)",
                position: "relative",
                overflow: "hidden"
              }}
            >
              <div className="absolute inset-0 overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-full bg-[#00FFFF] opacity-5 transform rotate-45 translate-x-1/3"></div>
                <div className="absolute top-0 right-0 w-64 h-64 bg-[#39FF14] rounded-full opacity-10 filter blur-3xl"></div>
              </div>
              {isOwnProfile && (
                <button className="absolute bottom-4 right-4 p-2 rounded-lg bg-[#1A1A1A] bg-opacity-60 text-white hover:bg-opacity-80 transition-colors">
                  <Edit size={18} />
                </button>
              )}
            </div>
            
            {/* Profile Info */}
            <div className="p-6 relative">
              {/* Avatar */}
              <div className="absolute -top-16 left-6 w-32 h-32 rounded-full bg-gradient-to-br from-[#00FFFF] to-[#131926] p-1">
                <div className="w-full h-full rounded-full bg-[#1A1A1A] flex items-center justify-center overflow-hidden">
                  {profileUser.profileImage ? (
                    <img 
                      src={profileUser.profileImage} 
                      alt={profileUser.username} 
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <span className="text-4xl font-bold text-[#00FFFF]">
                      {profileUser.firstName ? profileUser.firstName[0] : profileUser.username[0].toUpperCase()}
                    </span>
                  )}
                </div>
              </div>
              
              <div className="ml-40">
                <div className="flex justify-between items-start">
                  <div>
                    <h1 className="text-2xl font-bold text-white">
                      {profileUser.firstName} {profileUser.lastName}
                    </h1>
                    <p className="text-gray-400">@{profileUser.username}</p>
                  </div>
                  
                  <div className="flex space-x-2">
                    {isOwnProfile ? (
                      <Link href="/settings">
                        <a className="px-4 py-2 rounded-xl border border-[#00FFFF] text-[#00FFFF] hover:bg-[#00FFFF] hover:bg-opacity-10 transition-colors">
                          <Edit size={16} className="mr-2 inline-block" />
                          Edit Profile
                        </a>
                      </Link>
                    ) : (
                      <>
                        <button 
                          className="px-4 py-2 rounded-xl bg-[#00FFFF] text-black font-medium hover:opacity-90 transition-opacity flex items-center"
                          onClick={() => friendRequestMutation.mutate(profileUser.id)}
                          disabled={friendRequestMutation.isPending}
                        >
                          {friendRequestMutation.isPending ? (
                            <Loader2 className="h-4 w-4 animate-spin mr-2" />
                          ) : (
                            <UserPlus size={16} className="mr-2" />
                          )}
                          Connect
                        </button>
                        <button className="px-4 py-2 rounded-xl border border-gray-700 text-gray-200 hover:border-gray-500 transition-colors flex items-center">
                          <Mail size={16} className="mr-2" />
                          Message
                        </button>
                      </>
                    )}
                    <button className="p-2 rounded-xl border border-gray-700 text-gray-400 hover:border-gray-500 transition-colors">
                      <Share size={16} />
                    </button>
                  </div>
                </div>
                
                {/* Bio */}
                <div className="mt-4 max-w-3xl">
                  <p className="text-gray-300">
                    {profileUser.bio || "No bio provided"}
                  </p>
                </div>
                
                {/* Skills */}
                {profileUser.skills && profileUser.skills.length > 0 && (
                  <div className="mt-4 flex flex-wrap gap-2">
                    {profileUser.skills.map((skill, index) => (
                      <SkillBadge
                        key={index}
                        skill={skill}
                        color={index % 3 === 0 ? "blue" : index % 3 === 1 ? "green" : "gold"}
                      />
                    ))}
                  </div>
                )}
                
                {/* Stats */}
                <div className="flex space-x-8 mt-6">
                  <div className="text-center">
                    <p className="text-xl font-semibold text-white">128</p>
                    <p className="text-sm text-gray-400">Posts</p>
                  </div>
                  <div className="text-center">
                    <p className="text-xl font-semibold text-white">1.2k</p>
                    <p className="text-sm text-gray-400">Followers</p>
                  </div>
                  <div className="text-center">
                    <p className="text-xl font-semibold text-white">865</p>
                    <p className="text-sm text-gray-400">Following</p>
                  </div>
                  <div className="text-center">
                    <p className="text-xl font-semibold text-[#00FFFF]">Pro</p>
                    <p className="text-sm text-gray-400">Status</p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
          
          {/* Tabs Section */}
          <motion.div variants={itemVariants}>
            <Tabs defaultValue="posts" className="w-full">
              <div className="flex justify-between items-center mb-6">
                <TabsList className="bg-[#131926] border border-gray-800 p-1">
                  <TabsTrigger
                    value="posts"
                    className="data-[state=active]:bg-[#00FFFF] data-[state=active]:text-black"
                  >
                    Posts
                  </TabsTrigger>
                  <TabsTrigger
                    value="skills"
                    className="data-[state=active]:bg-[#00FFFF] data-[state=active]:text-black"
                  >
                    Skills
                  </TabsTrigger>
                  <TabsTrigger
                    value="saved"
                    className="data-[state=active]:bg-[#00FFFF] data-[state=active]:text-black"
                  >
                    Saved
                  </TabsTrigger>
                </TabsList>
                
                <div className="flex space-x-2 bg-[#131926] rounded-lg p-1">
                  <button
                    className={`p-2 rounded-lg ${viewMode === 'grid' ? 'bg-[#1A1A1A] text-[#00FFFF]' : 'text-gray-400'}`}
                    onClick={() => setViewMode('grid')}
                  >
                    <Grid size={18} />
                  </button>
                  <button
                    className={`p-2 rounded-lg ${viewMode === 'list' ? 'bg-[#1A1A1A] text-[#00FFFF]' : 'text-gray-400'}`}
                    onClick={() => setViewMode('list')}
                  >
                    <List size={18} />
                  </button>
                </div>
              </div>

              <TabsContent value="posts">
                {postsLoading ? (
                  <div className="flex justify-center py-12">
                    <Loader2 className="h-10 w-10 animate-spin text-[#00FFFF]" />
                  </div>
                ) : postsError ? (
                  <div className="text-center py-10 bg-[#1A1A1A] bg-opacity-25 backdrop-blur-md rounded-3xl p-6 border border-gray-800">
                    <p className="text-red-400">Failed to load posts</p>
                  </div>
                ) : (
                  <motion.div
                    className={viewMode === 'grid' ? 'grid grid-cols-2 md:grid-cols-3 gap-6' : 'space-y-6'}
                    variants={containerVariants}
                    initial="hidden"
                    animate="visible"
                  >
                    {posts && posts.length > 0 ? (
                      viewMode === 'list' ? (
                        posts.map((post) => (
                          <motion.div key={post.id} variants={itemVariants}>
                            <PostCard post={post} user={profileUser} />
                          </motion.div>
                        ))
                      ) : (
                        posts.map((post) => (
                          <motion.div
                            key={post.id}
                            className="bg-[#1A1A1A] bg-opacity-25 backdrop-blur-md rounded-3xl overflow-hidden border border-gray-800 hover:border-[#00FFFF] transition-colors"
                            variants={itemVariants}
                          >
                            {post.image && (
                              <div className="h-48 bg-[#131926] overflow-hidden">
                                <img src={post.image} alt="" className="w-full h-full object-cover" />
                              </div>
                            )}
                            <div className="p-4">
                              <p className="text-gray-300 line-clamp-2 mb-3">{post.content}</p>
                              <div className="flex justify-between items-center">
                                <div className="flex items-center space-x-2 text-sm text-gray-400">
                                  <span>{post.likes} likes</span>
                                  <span>•</span>
                                  <span>{post.comments} comments</span>
                                </div>
                              </div>
                            </div>
                          </motion.div>
                        ))
                      )
                    ) : (
                      <div className="col-span-full text-center py-10 bg-[#1A1A1A] bg-opacity-25 backdrop-blur-md rounded-3xl p-6 border border-gray-800">
                        <p className="text-gray-400 mb-2">No posts yet</p>
                        <p className="text-sm text-gray-500">
                          {isOwnProfile 
                            ? "Share your first post with the community!"
                            : `${profileUser.firstName || profileUser.username} hasn't posted anything yet.`
                          }
                        </p>
                      </div>
                    )}
                  </motion.div>
                )}
              </TabsContent>
              
              <TabsContent value="skills">
                <div className="bg-[#1A1A1A] bg-opacity-25 backdrop-blur-md rounded-3xl p-6 border border-gray-800">
                  <h2 className="text-xl font-semibold mb-6">Professional Skills</h2>
                  
                  {profileUser.skills && profileUser.skills.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {profileUser.skills.map((skill, index) => (
                        <div 
                          key={index}
                          className="bg-[#131926] rounded-2xl p-5 border border-gray-700 hover:border-[#00FFFF] transition-colors"
                        >
                          <div className="flex items-center space-x-3 mb-3">
                            <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                              index % 3 === 0 
                                ? 'bg-[#00FFFF] bg-opacity-20 text-[#00FFFF]' 
                                : index % 3 === 1 
                                  ? 'bg-[#39FF14] bg-opacity-20 text-[#39FF14]' 
                                  : 'bg-[#FFD700] bg-opacity-20 text-[#FFD700]'
                            }`}>
                              <span className="text-xl">{skill[0]}</span>
                            </div>
                            <h3 className="font-medium text-white">{skill}</h3>
                          </div>
                          
                          <div className="w-full bg-gray-700 h-2 rounded-full overflow-hidden">
                            <div
                              className={`h-full ${
                                index % 3 === 0 
                                  ? 'bg-[#00FFFF]' 
                                  : index % 3 === 1 
                                    ? 'bg-[#39FF14]' 
                                    : 'bg-[#FFD700]'
                              }`}
                              style={{ width: `${85 - (index * 7)}%` }}
                            ></div>
                          </div>
                          
                          <p className="text-gray-400 text-sm mt-3">
                            {index % 3 === 0 
                              ? 'Expert level with 5+ years experience' 
                              : index % 3 === 1 
                                ? 'Intermediate with practical projects' 
                                : 'Continuously improving'
                            }
                          </p>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <p className="text-gray-400 mb-2">No skills added yet</p>
                      {isOwnProfile && (
                        <Link href="/settings">
                          <a className="text-[#00FFFF] hover:underline">
                            Add your skills in profile settings
                          </a>
                        </Link>
                      )}
                    </div>
                  )}
                </div>
              </TabsContent>
              
              <TabsContent value="saved">
                <div className="text-center py-10 bg-[#1A1A1A] bg-opacity-25 backdrop-blur-md rounded-3xl p-6 border border-gray-800">
                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-[#131926] mb-4">
                    <Bookmark size={24} className="text-[#00FFFF]" />
                  </div>
                  <h2 className="text-xl font-medium text-white mb-2">Your Saved Items</h2>
                  <p className="text-gray-400 mb-6">
                    {isOwnProfile 
                      ? "You haven't saved any posts yet. Items you save will appear here."
                      : "This user's saved items are private."
                    }
                  </p>
                  {isOwnProfile && (
                    <Link href="/discover">
                      <a className="px-5 py-2 rounded-xl bg-[#00FFFF] text-black font-medium hover:opacity-90 transition-opacity">
                        Discover Content
                      </a>
                    </Link>
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </motion.div>
        </motion.div>
      </div>
    </MainLayout>
  );
}
