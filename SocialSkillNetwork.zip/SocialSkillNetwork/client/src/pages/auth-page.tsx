import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { User, InsertUser } from "@shared/schema";
import { 
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { SkillBadge } from "@/components/ui/skill-badge";
import { useAuth } from "@/hooks/use-auth";

// Login schema
const loginUserSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required")
});

// Skills array for registration
const availableSkills = [
  "Web Dev", "UI/UX", "AI/ML", "Data Science", 
  "Mobile Dev", "DevOps", "Cybersecurity", "Game Dev"
];

export default function AuthPage() {
  const [location, setLocation] = useLocation();
  const { user, isLoading, loginMutation, registerMutation } = useAuth();
  const [isLoginView, setIsLoginView] = useState(true);
  const [selectedSkills, setSelectedSkills] = useState<string[]>([]);
  
  // Login form
  const loginForm = useForm<z.infer<typeof loginUserSchema>>({
    resolver: zodResolver(loginUserSchema),
    defaultValues: {
      username: "",
      password: ""
    }
  });

  // Register form schema - create a new schema that includes termsAccepted
  const registerSchema = z.object({
    username: z.string().min(1, "Username is required"),
    password: z.string().min(6, "Password must be at least 6 characters"),
    confirmPassword: z.string().min(1, "Please confirm your password"),
    firstName: z.string().optional().or(z.literal("")),
    lastName: z.string().optional().or(z.literal("")),
    email: z.string().email("Invalid email address").optional().or(z.literal("")),
    bio: z.string().optional().or(z.literal("")),
    profileImage: z.string().optional().or(z.literal("")),
    skills: z.array(z.string()).min(1, "At least one skill is required"),
    termsAccepted: z.boolean().refine((val) => val === true, {
      message: "You must accept the terms and conditions",
    }),
  }).refine((data) => data.password === data.confirmPassword, {
    message: "Passwords don't match",
    path: ["confirmPassword"],
  });

  const registerForm = useForm<z.infer<typeof registerSchema>>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      username: "",
      email: "",
      password: "",
      confirmPassword: "",
      termsAccepted: false,
      skills: []
    }
  });
  
  // Effect to sync selected skills with form values whenever selected skills change
  useEffect(() => {
    registerForm.setValue("skills", selectedSkills);
  }, [selectedSkills, registerForm]);

  // If the user is already logged in, redirect to dashboard
  useEffect(() => {
    if (user && !isLoading) {
      setLocation("/dashboard");
    }
  }, [user, isLoading, setLocation]);

  // Handle login form submission
  const onLoginSubmit = (values: z.infer<typeof loginUserSchema>) => {
    loginMutation.mutate(values);
  };

  // Handle register form submission
  const onRegisterSubmit = (values: z.infer<typeof registerSchema>) => {
    // Create a properly typed object for the mutation
    const registerData: InsertUser = {
      username: values.username,
      password: values.password,
      confirmPassword: values.confirmPassword,
      firstName: values.firstName,
      lastName: values.lastName,
      email: values.email,
      bio: values.bio,
      profileImage: values.profileImage,
      skills: selectedSkills, // Use the selected skills from state
    };
    
    registerMutation.mutate(registerData);
  };

  // Toggle selected skill
  const toggleSkill = (skill: string) => {
    let newSkills;
    if (selectedSkills.includes(skill)) {
      newSkills = selectedSkills.filter(s => s !== skill);
      setSelectedSkills(newSkills);
    } else {
      newSkills = [...selectedSkills, skill];
      setSelectedSkills(newSkills);
    }
    
    // Update the form value directly
    registerForm.setValue("skills", newSkills);
  };

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        duration: 0.5,
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.3 }
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-[#0D0D0D] px-4 py-8">
      <motion.div
        initial="hidden"
        animate="visible"
        variants={containerVariants}
        className="w-full max-w-md rounded-3xl p-8 shadow-lg bg-[#1A1A1A] bg-opacity-25 backdrop-blur-md border border-gray-800"
        style={{
          backgroundImage: "linear-gradient(to bottom, rgba(26, 26, 26, 0.25), rgba(19, 25, 38, 0.25))",
          backdropFilter: "blur(10px)",
          borderColor: "rgba(255, 255, 255, 0.05)",
          boxShadow: "0 0 15px rgba(0, 0, 0, 0.3)"
        }}
      >
        <motion.div variants={itemVariants} className="text-center mb-8">
          <h1 className="font-poppins font-bold text-4xl mb-2 text-[#00FFFF]">
            {isLoginView ? "Welcome Back" : "Join NexaSkill"}
          </h1>
          <p className="text-gray-300">
            {isLoginView ? "Sign in to your account" : "Create your account"}
          </p>
        </motion.div>
        
        {isLoginView ? (
          <Form {...loginForm}>
            <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-6">
              <motion.div variants={itemVariants}>
                <FormField
                  control={loginForm.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-white">Username</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="Enter your username"
                          className="bg-[#131926] border-gray-700 focus:border-[#00FFFF] text-white"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </motion.div>
              
              <motion.div variants={itemVariants}>
                <FormField
                  control={loginForm.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-white">Password</FormLabel>
                      <FormControl>
                        <Input
                          type="password"
                          placeholder="Enter your password"
                          className="bg-[#131926] border-gray-700 focus:border-[#00FFFF] text-white"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </motion.div>
              
              <motion.div variants={itemVariants} className="flex items-center justify-between">
                <div className="flex items-center">
                  <Checkbox id="remember" className="text-[#00FFFF] border-gray-600" />
                  <label htmlFor="remember" className="ml-2 text-sm text-gray-300">
                    Remember me
                  </label>
                </div>
                <a href="#" className="text-sm text-[#00FFFF] hover:underline">
                  Forgot password?
                </a>
              </motion.div>
              
              <motion.div variants={itemVariants}>
                <Button
                  type="submit"
                  className="w-full py-6 rounded-2xl bg-gradient-to-r from-[#00FFFF] to-[#39FF14] text-black font-medium hover:opacity-90 transition-opacity"
                  disabled={loginMutation.isPending}
                >
                  {loginMutation.isPending ? "Signing in..." : "Sign In"}
                </Button>
              </motion.div>
              
              <motion.div variants={itemVariants} className="text-center text-sm">
                <span className="text-gray-400">Don't have an account?</span>
                <button
                  type="button"
                  className="text-[#00FFFF] hover:underline ml-1"
                  onClick={() => setIsLoginView(false)}
                >
                  Sign Up
                </button>
              </motion.div>
              
              <motion.div variants={itemVariants} className="relative flex items-center justify-center mt-6">
                <div className="border-t border-gray-700 absolute w-full"></div>
                <div className="bg-[#1A1A1A] px-4 relative z-10 text-sm text-gray-400">OR CONTINUE WITH</div>
              </motion.div>
              
              <motion.div variants={itemVariants} className="grid grid-cols-2 gap-4">
                <Button
                  type="button"
                  variant="outline"
                  className="bg-[#131926] border-gray-700 hover:border-gray-500 text-white"
                >
                  <i className="fab fa-google mr-2"></i>
                  Google
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  className="bg-[#131926] border-gray-700 hover:border-gray-500 text-white"
                >
                  <i className="fab fa-github mr-2"></i>
                  GitHub
                </Button>
              </motion.div>
            </form>
          </Form>
        ) : (
          <Form {...registerForm}>
            <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)} className="space-y-5">
              <motion.div variants={itemVariants} className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-white text-sm font-medium block mb-1.5">First Name</label>
                  <input
                    type="text"
                    placeholder="First name"
                    className="flex h-10 w-full rounded-md border border-gray-700 bg-[#131926] px-3 py-2 text-sm ring-offset-background focus:border-[#00FFFF] focus:outline-none focus:ring-2 focus:ring-offset-2 text-white"
                    value={registerForm.watch("firstName") || ""}
                    onChange={(e) => registerForm.setValue("firstName", e.target.value)}
                  />
                </div>
                <div>
                  <label className="text-white text-sm font-medium block mb-1.5">Last Name</label>
                  <input
                    type="text"
                    placeholder="Last name"
                    className="flex h-10 w-full rounded-md border border-gray-700 bg-[#131926] px-3 py-2 text-sm ring-offset-background focus:border-[#00FFFF] focus:outline-none focus:ring-2 focus:ring-offset-2 text-white"
                    value={registerForm.watch("lastName") || ""}
                    onChange={(e) => registerForm.setValue("lastName", e.target.value)}
                  />
                </div>
              </motion.div>
              
              <motion.div variants={itemVariants}>
                <div>
                  <label className="text-white text-sm font-medium block mb-1.5">Email</label>
                  <input
                    type="email"
                    placeholder="Enter your email"
                    className="flex h-10 w-full rounded-md border border-gray-700 bg-[#131926] px-3 py-2 text-sm ring-offset-background focus:border-[#00FFFF] focus:outline-none focus:ring-2 focus:ring-offset-2 text-white"
                    value={registerForm.watch("email") || ""}
                    onChange={(e) => registerForm.setValue("email", e.target.value)}
                  />
                </div>
              </motion.div>
              
              <motion.div variants={itemVariants}>
                <FormField
                  control={registerForm.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-white">Username</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="Choose a username"
                          className="bg-[#131926] border-gray-700 focus:border-[#00FFFF] text-white"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </motion.div>
              
              <motion.div variants={itemVariants}>
                <FormField
                  control={registerForm.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-white">Password</FormLabel>
                      <FormControl>
                        <Input
                          type="password"
                          placeholder="Create a password"
                          className="bg-[#131926] border-gray-700 focus:border-[#00FFFF] text-white"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </motion.div>
              
              <motion.div variants={itemVariants}>
                <FormField
                  control={registerForm.control}
                  name="confirmPassword"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-white">Confirm Password</FormLabel>
                      <FormControl>
                        <Input
                          type="password"
                          placeholder="Confirm your password"
                          className="bg-[#131926] border-gray-700 focus:border-[#00FFFF] text-white"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </motion.div>
              
              <motion.div variants={itemVariants}>
                <FormLabel className="text-white block mb-2">Select your skills (min 1)</FormLabel>
                <div className="flex flex-wrap gap-2">
                  {availableSkills.map((skill, index) => (
                    <SkillBadge
                      key={index}
                      skill={skill}
                      selected={selectedSkills.includes(skill)}
                      clickable
                      onSelectChange={(selected) => toggleSkill(skill)}
                    />
                  ))}
                </div>
                {registerForm.formState.errors.skills && (
                  <p className="text-sm font-medium text-destructive mt-2">
                    {registerForm.formState.errors.skills.message as string}
                  </p>
                )}
              </motion.div>
              
              <motion.div variants={itemVariants}>
                <FormField
                  control={registerForm.control}
                  name="termsAccepted"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                          className="text-[#00FFFF] border-gray-600"
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel className="text-sm text-gray-300">
                          I agree to the{" "}
                          <a href="#" className="text-[#00FFFF] hover:underline">
                            Terms of Service
                          </a>{" "}
                          and{" "}
                          <a href="#" className="text-[#00FFFF] hover:underline">
                            Privacy Policy
                          </a>
                        </FormLabel>
                        <FormMessage />
                      </div>
                    </FormItem>
                  )}
                />
              </motion.div>
              
              <motion.div variants={itemVariants}>
                <Button
                  type="submit"
                  className="w-full py-6 rounded-2xl bg-gradient-to-r from-[#00FFFF] to-[#39FF14] text-black font-medium hover:opacity-90 transition-opacity"
                  disabled={registerMutation.isPending}
                >
                  {registerMutation.isPending ? "Creating Account..." : "Create Account"}
                </Button>
              </motion.div>
              
              <motion.div variants={itemVariants} className="text-center text-sm">
                <span className="text-gray-400">Already have an account?</span>
                <button
                  type="button"
                  className="text-[#00FFFF] hover:underline ml-1"
                  onClick={() => setIsLoginView(true)}
                >
                  Sign In
                </button>
              </motion.div>
            </form>
          </Form>
        )}
      </motion.div>
    </div>
  );
}
