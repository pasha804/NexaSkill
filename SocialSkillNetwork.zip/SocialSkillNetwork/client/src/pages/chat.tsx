import { useState, useEffect, useRef } from "react";
import { useParams } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { MessageSquare, Send, Smile, Loader2 } from "lucide-react";
import { Send, Image, Paperclip, Smile, Search, Phone, Video, Info, MessageSquare, Loader2 } from "lucide-react";
import { MainLayout } from "@/components/layout/main-layout";
import { UserAvatar } from "@/components/user/user-avatar";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { User, Message } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";

export default function Chat() {
  const { userId } = useParams();
  const { user } = useAuth();
  const [message, setMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [selectedChat, setSelectedChat] = useState<number | null>(userId ? parseInt(userId) : null);
  const [searchTerm, setSearchTerm] = useState("");
  
  // Fetch friends
  const {
    data: friends,
    isLoading: friendsLoading,
    error: friendsError
  } = useQuery<{ user: User; status: string }[]>({
    queryKey: ["/api/friends"],
  });

  // Fetch messages for selected chat
  const {
    data: messages,
    isLoading: messagesLoading,
    error: messagesError
  } = useQuery<Message[]>({
    queryKey: ["/api/messages", selectedChat],
    enabled: selectedChat !== null,
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (data: { content: string; receiverId: number }) => {
      const res = await apiRequest("POST", "/api/messages", data);
      return res.json();
    },
    onSuccess: () => {
      setMessage("");
      queryClient.invalidateQueries({ queryKey: ["/api/messages", selectedChat] });
    }
  });

  // Filter friends by search term
  const filteredFriends = friends?.filter(friend => {
    if (!searchTerm) return true;
    
    const fullName = `${friend.user.firstName || ''} ${friend.user.lastName || ''}`.toLowerCase();
    return (
      friend.user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
      fullName.includes(searchTerm.toLowerCase())
    );
  });

  // Find current chat user
  const currentChatUser = friends?.find(friend => friend.user.id === selectedChat)?.user;

  // Handle message submission
  const handleSendMessage = () => {
    if (!message.trim() || !selectedChat || !user) return;
    
    sendMessageMutation.mutate({
      content: message,
      receiverId: selectedChat
    });
  };

  // Handle Enter key press
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  // Scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        duration: 0.3
      }
    }
  };

  const listVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.05
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 10 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.2 }
    }
  };

  return (
    <MainLayout>
      <div className="h-[calc(100vh-9rem)] flex">
        {/* Chat sidebar */}
        <motion.div 
          className="w-80 flex-shrink-0 border-r border-gray-800 overflow-hidden flex flex-col"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          <div className="p-4 border-b border-gray-800">
            <h2 className="font-semibold text-xl mb-4">Messages</h2>
            <div className="relative">
              <input
                type="text"
                placeholder="Search conversations..."
                className="w-full pl-10 pr-4 py-2 bg-[#131926] rounded-xl border border-gray-700 focus:border-[#00FFFF] focus:outline-none text-white"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
            </div>
          </div>
          
          <div className="flex-1 overflow-y-auto">
            {friendsLoading ? (
              <div className="flex justify-center items-center h-40">
                <Loader2 className="h-8 w-8 animate-spin text-[#00FFFF]" />
              </div>
            ) : friendsError ? (
              <div className="text-center py-6">
                <p className="text-red-400">Failed to load conversations</p>
              </div>
            ) : filteredFriends && filteredFriends.length > 0 ? (
              <motion.div
                className="divide-y divide-gray-800"
                variants={listVariants}
                initial="hidden"
                animate="visible"
              >
                {filteredFriends.map((friend) => (
                  <motion.div
                    key={friend.user.id}
                    className={`p-4 cursor-pointer hover:bg-[#131926] transition-colors ${selectedChat === friend.user.id ? 'bg-[#131926]' : ''}`}
                    onClick={() => setSelectedChat(friend.user.id)}
                    variants={itemVariants}
                  >
                    <div className="flex items-center space-x-3">
                      <div className="relative">
                        <UserAvatar user={friend.user} />
                        <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-[#0D0D0D] rounded-full"></span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-center">
                          <h3 className="font-medium text-white truncate">
                            {friend.user.firstName || friend.user.username}
                          </h3>
                          <span className="text-xs text-gray-400">12m</span>
                        </div>
                        <p className="text-sm text-gray-400 truncate">
                          {friend.user.id % 2 === 0 
                            ? "Hey, how's it going?" 
                            : "I was thinking about that project..."}
                        </p>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </motion.div>
            ) : (
              <div className="text-center py-10">
                <p className="text-gray-400">No conversations found</p>
                <p className="text-sm text-gray-500 mt-1">
                  {searchTerm ? "Try a different search term" : "Connect with friends to start chatting"}
                </p>
              </div>
            )}
          </div>
        </motion.div>
        
        {/* Chat main area */}
        <motion.div 
          className="flex-1 flex flex-col bg-[#0D0D0D]"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {selectedChat && currentChatUser ? (
            <>
              {/* Chat header */}
              <div className="p-4 border-b border-gray-800 flex justify-between items-center bg-[#1A1A1A] bg-opacity-25">
                <div className="flex items-center space-x-3">
                  <UserAvatar user={currentChatUser} />
                  <div>
                    <h3 className="font-medium text-white">
                      {currentChatUser.firstName} {currentChatUser.lastName}
                    </h3>
                    <p className="text-xs text-green-500">Online</p>
                  </div>
                </div>
                <div className="flex space-x-4">
                  <button className="text-gray-400 hover:text-[#00FFFF] transition-colors">
                    <Phone size={20} />
                  </button>
                  <button className="text-gray-400 hover:text-[#00FFFF] transition-colors">
                    <Video size={20} />
                  </button>
                  <button className="text-gray-400 hover:text-[#00FFFF] transition-colors">
                    <Info size={20} />
                  </button>
                </div>
              </div>
              
              {/* Messages area */}
              <div className="flex-1 overflow-y-auto p-4">
                {messagesLoading ? (
                  <div className="flex justify-center items-center h-40">
                    <Loader2 className="h-8 w-8 animate-spin text-[#00FFFF]" />
                  </div>
                ) : messagesError ? (
                  <div className="text-center py-6">
                    <p className="text-red-400">Failed to load messages</p>
                  </div>
                ) : messages && messages.length > 0 ? (
                  <motion.div
                    className="space-y-4"
                    variants={listVariants}
                    initial="hidden"
                    animate="visible"
                  >
                    {messages.map((msg) => {
                      const isOwn = msg.senderId === user?.id;
                      
                      return (
                        <motion.div
                          key={msg.id}
                          className={`flex ${isOwn ? 'justify-end' : 'justify-start'}`}
                          variants={itemVariants}
                        >
                          <div className={`max-w-[70%] ${isOwn ? 'order-2' : 'order-1'}`}>
                            {!isOwn && (
                              <UserAvatar 
                                user={currentChatUser} 
                                size="sm" 
                                className="inline-block mb-1 mr-2"
                              />
                            )}
                            <div className={`rounded-2xl p-3 ${isOwn 
                              ? 'bg-[#00FFFF] text-black ml-auto' 
                              : 'bg-[#1A1A1A] bg-opacity-50 text-white'
                            }`}>
                              <p>{msg.content}</p>
                              <p className={`text-xs mt-1 ${isOwn ? 'text-[#1A1A1A]' : 'text-gray-400'}`}>
                                {msg.createdAt && formatDistanceToNow(new Date(msg.createdAt), { addSuffix: true })}
                              </p>
                            </div>
                          </div>
                        </motion.div>
                      );
                    })}
                    <div ref={messagesEndRef} />
                  </motion.div>
                ) : (
                  <div className="text-center py-10">
                    <p className="text-gray-400">No messages yet</p>
                    <p className="text-sm text-gray-500 mt-1">
                      Send a message to start the conversation
                    </p>
                  </div>
                )}
              </div>
              
              {/* Message input */}
              <div className="p-4 border-t border-gray-800 bg-[#1A1A1A] bg-opacity-25">
                <div className="flex items-center space-x-2">
                  <button className="p-2 text-gray-400 hover:text-[#00FFFF] transition-colors">
                    <Paperclip size={20} />
                  </button>
                  <button className="p-2 text-gray-400 hover:text-[#00FFFF] transition-colors">
                    <Image size={20} />
                  </button>
                  <div className="flex-1 relative">
                    <textarea
                      placeholder="Type a message..."
                      className="w-full px-4 py-3 bg-[#131926] rounded-xl border border-gray-700 focus:border-[#00FFFF] focus:outline-none resize-none text-white"
                      rows={1}
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      onKeyDown={handleKeyPress}
                    />
                    <button className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-[#00FFFF] transition-colors">
                      <Smile size={20} />
                    </button>
                  </div>
                  <button 
                    className="p-3 rounded-xl bg-[#00FFFF] text-black hover:opacity-90 transition-opacity disabled:opacity-50"
                    onClick={handleSendMessage}
                    disabled={!message.trim() || sendMessageMutation.isPending}
                  >
                    {sendMessageMutation.isPending ? (
                      <Loader2 className="h-5 w-5 animate-spin" />
                    ) : (
                      <Send size={20} />
                    )}
                  </button>
                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center">
              <div className="text-center px-4">
                <div className="inline-block p-6 rounded-full bg-[#131926] mb-4">
                  <MessageSquare size={40} className="text-[#00FFFF]" />
                </div>
                <h3 className="text-xl font-medium text-white mb-2">Your Messages</h3>
                <p className="text-gray-400 max-w-md mb-6">
                  Send private messages to friends and collaborators
                </p>
                <button className="px-5 py-2 rounded-xl bg-[#00FFFF] text-black font-medium hover:opacity-90 transition-opacity">
                  Send a Message
                </button>
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </MainLayout>
  );
}
