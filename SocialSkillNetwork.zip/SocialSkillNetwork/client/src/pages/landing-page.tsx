import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { ChevronRight, Code, Video, Award, MessageSquare, Zap, Briefcase } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

export default function LandingPage() {
  const [location, setLocation] = useLocation();
  const { user, isLoading } = useAuth();
  
  // Redirect to dashboard if already logged in
  useEffect(() => {
    if (user && !isLoading) {
      setLocation("/dashboard");
    }
  }, [user, isLoading, setLocation]);

  // Animation variants
  const fadeIn = {
    hidden: { opacity: 0, y: 20 },
    visible: (delay: number) => ({
      opacity: 1,
      y: 0,
      transition: { 
        delay,
        duration: 0.5 
      }
    })
  };

  return (
    <div className="min-h-screen text-white bg-[#0D0D0D]">
      {/* Header/Navigation */}
      <header className="sticky top-0 z-50 py-4 px-6 border-b border-gray-800 bg-[#1A1A1A] bg-opacity-25 backdrop-blur-md">
        <div className="container mx-auto flex justify-between items-center">
          <div className="flex items-center">
            <h1 className="font-poppins font-bold text-3xl text-[#00FFFF]">NexaSkill</h1>
          </div>
          
          <nav className="hidden md:flex space-x-8 items-center">
            <a href="#features" className="text-white hover:text-[#00FFFF] transition-colors">Features</a>
            <a href="#categories" className="text-white hover:text-[#00FFFF] transition-colors">Skills</a>
            <a href="#testimonials" className="text-white hover:text-[#00FFFF] transition-colors">Testimonials</a>
            <a href="#pricing" className="text-white hover:text-[#00FFFF] transition-colors">Pricing</a>
          </nav>
          
          <div className="flex items-center space-x-4">
            <button 
              onClick={() => setLocation("/auth")}
              className="px-5 py-2 rounded-2xl border border-[#00FFFF] text-[#00FFFF] hover:bg-[#00FFFF] hover:text-black transition-colors"
            >
              Sign In
            </button>
            <button 
              onClick={() => setLocation("/auth")}
              className="px-5 py-2 rounded-2xl bg-gradient-to-r from-[#00FFFF] to-[#39FF14] text-black font-medium hover:opacity-90 transition-opacity hidden md:block"
            >
              Join Free
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial="hidden"
            animate="visible"
            custom={0.1}
            variants={fadeIn}
          >
            <h1 className="font-poppins font-bold text-4xl md:text-5xl lg:text-6xl leading-tight mb-6">
              Connect with<br /> 
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#00FFFF] to-[#39FF14]">
                skilled professionals
              </span><br /> 
              collaborate & grow
            </h1>
            <p className="text-gray-300 text-lg mb-8 max-w-lg">
              NexaSkill brings together experts across various fields. Find mentors, collaborators, and friends who share your passion for technology and innovation.
            </p>
            <div className="flex flex-wrap gap-4">
              <button 
                onClick={() => setLocation("/auth")}
                className="px-8 py-3 rounded-2xl bg-gradient-to-r from-[#00FFFF] to-[#39FF14] text-black font-medium hover:opacity-90 transition-opacity transform hover:scale-[1.02]"
                style={{ boxShadow: "0 0 15px rgba(0, 255, 255, 0.3)" }}
              >
                Get Started
              </button>
              <button 
                className="px-8 py-3 rounded-2xl bg-[#1A1A1A] bg-opacity-25 backdrop-blur-md border border-gray-700 hover:border-[#00FFFF] transition-colors"
                style={{ backdropFilter: "blur(10px)" }}
              >
                Learn More
              </button>
            </div>
            <div className="mt-8 flex items-center">
              <div className="flex -space-x-2">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="w-10 h-10 rounded-full border-2 border-[#0D0D0D] bg-gradient-to-br from-[#00FFFF] to-[#131926] flex items-center justify-center text-xs font-bold">
                    {i}
                  </div>
                ))}
              </div>
              <div className="ml-4">
                <p className="text-sm text-gray-300">Joined by <span className="text-[#00FFFF] font-medium">5,000+</span> professionals</p>
              </div>
            </div>
          </motion.div>
          
          <motion.div
            initial="hidden"
            animate="visible"
            custom={0.3}
            variants={fadeIn}
            className="relative"
          >
            <div className="absolute -top-10 -left-10 w-64 h-64 bg-[#00FFFF] rounded-full opacity-10 filter blur-3xl"></div>
            <div className="absolute -bottom-10 -right-10 w-64 h-64 bg-[#39FF14] rounded-full opacity-10 filter blur-3xl"></div>
            <div 
              className="relative bg-[#1A1A1A] bg-opacity-25 backdrop-blur-md rounded-3xl overflow-hidden p-2"
              style={{ 
                boxShadow: "0 0 15px rgba(0, 255, 255, 0.2)",
                borderColor: "rgba(255, 255, 255, 0.05)"
              }}
            >
              <img 
                src="https://images.unsplash.com/photo-1552664730-d307ca884978" 
                alt="Professional collaboration"
                className="rounded-2xl"
              />
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 px-4 bg-gradient-to-b from-[#0D0D0D] to-[#131926]">
        <div className="container mx-auto text-center mb-16">
          <motion.h2 
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            custom={0.1}
            variants={fadeIn}
            className="font-poppins font-bold text-3xl md:text-4xl mb-4"
          >
            Powerful Features
          </motion.h2>
          <motion.p 
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            custom={0.2}
            variants={fadeIn}
            className="text-gray-300 max-w-2xl mx-auto"
          >
            Connect, collaborate, and grow with our comprehensive platform designed for professionals
          </motion.p>
        </div>
        
        <div className="container mx-auto grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {[
            {
              icon: Code,
              title: "Skill-Based Matchmaking",
              desc: "Find professionals with complementary skills for your next project or collaboration.",
              color: "from-[#00FFFF] to-[#131926]",
              delay: 0.3
            },
            {
              icon: Video,
              title: "Virtual Meetings",
              desc: "Host and join virtual meetings with your connections directly on the platform.",
              color: "from-[#39FF14] to-[#131926]",
              delay: 0.4
            },
            {
              icon: Award,
              title: "Skill Badges",
              desc: "Earn and showcase verified badges that highlight your expertise and accomplishments.",
              color: "from-[#FFD700] to-[#131926]",
              delay: 0.5
            },
            {
              icon: MessageSquare,
              title: "Real-time Chat",
              desc: "Connect instantly with professionals through our secure messaging system.",
              color: "from-[#00FFFF] to-[#131926]",
              delay: 0.6
            },
            {
              icon: Zap,
              title: "Discovery Feed",
              desc: "Explore content tailored to your skills and interests through our personalized feed.",
              color: "from-[#39FF14] to-[#131926]",
              delay: 0.7
            },
            {
              icon: Briefcase,
              title: "Mentorship",
              desc: "Book 1-on-1 sessions with industry experts or offer your expertise to others.",
              color: "from-[#FFD700] to-[#131926]",
              delay: 0.8
            }
          ].map((feature, index) => (
            <motion.div 
              key={index}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              custom={feature.delay}
              variants={fadeIn}
              className="bg-[#1A1A1A] bg-opacity-25 backdrop-blur-md rounded-3xl p-6 hover:border-[#00FFFF] border border-gray-800 transition-colors"
              style={{ 
                backgroundImage: "linear-gradient(to bottom, rgba(26, 26, 26, 0.25), rgba(19, 25, 38, 0.25))",
                backdropFilter: "blur(10px)",
                borderColor: "rgba(255, 255, 255, 0.05)"
              }}
            >
              <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${feature.color} flex items-center justify-center mb-5`}>
                <feature.icon className="text-white" size={24} />
              </div>
              <h3 className="font-poppins font-semibold text-xl mb-3">{feature.title}</h3>
              <p className="text-gray-300">{feature.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 relative overflow-hidden">
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-[#00FFFF] rounded-full opacity-10 filter blur-3xl"></div>
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-[#39FF14] rounded-full opacity-10 filter blur-3xl"></div>
        
        <div className="container mx-auto relative">
          <motion.div 
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            custom={0.2}
            variants={fadeIn}
            className="bg-[#1A1A1A] bg-opacity-25 backdrop-blur-md rounded-3xl p-10 md:p-16 text-center max-w-4xl mx-auto"
            style={{ 
              boxShadow: "0 0 15px rgba(0, 255, 255, 0.2)",
              borderColor: "rgba(255, 255, 255, 0.05)"
            }}
          >
            <h2 className="font-poppins font-bold text-3xl md:text-4xl mb-6">Ready to expand your professional network?</h2>
            <p className="text-gray-300 text-lg mb-8 max-w-2xl mx-auto">
              Join thousands of professionals on NexaSkill today and start connecting with like-minded individuals in your field.
            </p>
            <button 
              onClick={() => setLocation("/auth")}
              className="px-8 py-4 rounded-2xl bg-gradient-to-r from-[#00FFFF] to-[#39FF14] text-black font-medium hover:opacity-90 transition-opacity transform hover:scale-[1.02] text-lg"
              style={{ boxShadow: "0 0 15px rgba(0, 255, 255, 0.3)" }}
            >
              Join NexaSkill Now <ChevronRight className="inline ml-1" size={18} />
            </button>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 border-t border-gray-800">
        <div className="container mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-10">
            <div>
              <h3 className="font-poppins font-semibold text-lg mb-4">Platform</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-[#00FFFF] transition-colors">Features</a></li>
                <li><a href="#" className="text-gray-400 hover:text-[#00FFFF] transition-colors">Mentorship</a></li>
                <li><a href="#" className="text-gray-400 hover:text-[#00FFFF] transition-colors">Collaboration</a></li>
                <li><a href="#" className="text-gray-400 hover:text-[#00FFFF] transition-colors">Skills</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-poppins font-semibold text-lg mb-4">Resources</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-[#00FFFF] transition-colors">Blog</a></li>
                <li><a href="#" className="text-gray-400 hover:text-[#00FFFF] transition-colors">Documentation</a></li>
                <li><a href="#" className="text-gray-400 hover:text-[#00FFFF] transition-colors">Community</a></li>
                <li><a href="#" className="text-gray-400 hover:text-[#00FFFF] transition-colors">Tutorials</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-poppins font-semibold text-lg mb-4">Company</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-[#00FFFF] transition-colors">About Us</a></li>
                <li><a href="#" className="text-gray-400 hover:text-[#00FFFF] transition-colors">Careers</a></li>
                <li><a href="#" className="text-gray-400 hover:text-[#00FFFF] transition-colors">Press</a></li>
                <li><a href="#" className="text-gray-400 hover:text-[#00FFFF] transition-colors">Contact</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-poppins font-semibold text-lg mb-4">Legal</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-[#00FFFF] transition-colors">Terms</a></li>
                <li><a href="#" className="text-gray-400 hover:text-[#00FFFF] transition-colors">Privacy</a></li>
                <li><a href="#" className="text-gray-400 hover:text-[#00FFFF] transition-colors">Cookies</a></li>
                <li><a href="#" className="text-gray-400 hover:text-[#00FFFF] transition-colors">Licenses</a></li>
              </ul>
            </div>
          </div>
          
          <div className="pt-8 border-t border-gray-800 flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <h2 className="font-poppins font-bold text-2xl text-[#00FFFF] mb-2">NexaSkill</h2>
              <p className="text-gray-400 text-sm">© {new Date().getFullYear()} NexaSkill. All rights reserved.</p>
            </div>
            
            <div className="flex space-x-6">
              {["twitter", "linkedin", "github", "discord"].map((social) => (
                <a 
                  key={social}
                  href="#" 
                  className="text-gray-400 hover:text-[#00FFFF] transition-colors"
                  aria-label={social}
                >
                  <i className={`fab fa-${social} text-xl`}></i>
                </a>
              ))}
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
