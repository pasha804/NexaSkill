import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Image, Paperclip, X, UploadCloud, Tag, Send } from "lucide-react";
import { MainLayout } from "@/components/layout/main-layout";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { SkillBadge } from "@/components/ui/skill-badge";
import { UserAvatar } from "@/components/user/user-avatar";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { InsertPost } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function CreatePost() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [content, setContent] = useState("");
  const [image, setImage] = useState<string | null>(null);
  const [selectedSkills, setSelectedSkills] = useState<string[]>([]);
  const [showSkillSelector, setShowSkillSelector] = useState(false);

  // All available skills (replace with actual skills from user profile or database)
  const availableSkills = [
    "React", "Node.js", "TypeScript", "JavaScript", "Python", "Go",
    "UI Design", "UX Design", "Product Management", "Agile", "Scrum",
    "DevOps", "Cloud", "AWS", "Azure", "Google Cloud", "Docker", 
    "Kubernetes", "Machine Learning", "AI", "Data Science", "Blockchain"
  ];

  // Create post mutation
  const createPostMutation = useMutation({
    mutationFn: async (postData: InsertPost) => {
      const res = await apiRequest("POST", "/api/posts", postData);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({queryKey: ["/api/posts"]});
      toast({
        title: "Post created",
        description: "Your post has been published successfully.",
      });
      navigate("/dashboard");
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create post. Please try again.",
        variant: "destructive",
      });
    }
  });

  // Handle image upload
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check file type
    if (!file.type.startsWith("image/")) {
      toast({
        title: "Invalid file",
        description: "Please upload an image file.",
        variant: "destructive",
      });
      return;
    }

    // Check file size (5MB limit)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Please upload an image smaller than 5MB.",
        variant: "destructive",
      });
      return;
    }

    // Convert to base64 for preview
    const reader = new FileReader();
    reader.onload = () => {
      setImage(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  // Handle skill selection
  const toggleSkill = (skill: string) => {
    if (selectedSkills.includes(skill)) {
      setSelectedSkills(selectedSkills.filter(s => s !== skill));
    } else {
      setSelectedSkills([...selectedSkills, skill]);
    }
  };

  // Handle post submission
  const handleSubmit = () => {
    if (!content.trim()) {
      toast({
        title: "Empty post",
        description: "Please write something before posting.",
        variant: "destructive",
      });
      return;
    }

    createPostMutation.mutate({
      content,
      image,
      skills: selectedSkills.length > 0 ? selectedSkills : null
    });
  };

  return (
    <MainLayout>
      <div className="container max-w-2xl mx-auto px-4 py-8">
        <Card className="p-6 bg-[#1A1A1A] border-gray-800">
          <h1 className="text-2xl font-bold text-white mb-6">Create Post</h1>
          
          <div className="flex items-start space-x-4 mb-4">
            {user && <UserAvatar user={user} size="md" />}
            <div className="flex-1">
              <Textarea
                placeholder="What's on your mind? Share knowledge, ask questions, or showcase your work..."
                className="bg-[#131926] border-gray-700 text-white min-h-[150px] resize-none p-4"
                value={content}
                onChange={(e) => setContent(e.target.value)}
              />
            </div>
          </div>
          
          {/* Image preview */}
          {image && (
            <div className="relative mt-4 mb-6 rounded-xl overflow-hidden">
              <img src={image} alt="Upload preview" className="w-full h-auto rounded-xl" />
              <button
                className="absolute top-2 right-2 p-1 rounded-full bg-black bg-opacity-50 text-white hover:bg-opacity-70"
                onClick={() => setImage(null)}
              >
                <X size={20} />
              </button>
            </div>
          )}
          
          {/* Selected skills */}
          {selectedSkills.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-4 mb-6">
              {selectedSkills.map(skill => (
                <SkillBadge
                  key={skill}
                  skill={skill}
                  selected
                  clickable
                  onSelectChange={() => toggleSkill(skill)}
                />
              ))}
            </div>
          )}
          
          {/* Skill selector */}
          {showSkillSelector && (
            <Card className="p-4 bg-[#131926] border-gray-700 mb-6">
              <div className="flex justify-between items-center mb-3">
                <h3 className="text-white text-sm font-medium">Select Skills</h3>
                <button
                  className="text-gray-400 hover:text-white"
                  onClick={() => setShowSkillSelector(false)}
                >
                  <X size={18} />
                </button>
              </div>
              <div className="flex flex-wrap gap-2 max-h-[150px] overflow-y-auto">
                {availableSkills.map(skill => (
                  <SkillBadge
                    key={skill}
                    skill={skill}
                    selected={selectedSkills.includes(skill)}
                    clickable
                    onSelectChange={() => toggleSkill(skill)}
                  />
                ))}
              </div>
            </Card>
          )}
          
          <div className="flex items-center justify-between mt-4">
            <div className="flex space-x-2">
              <div className="relative">
                <input
                  type="file"
                  id="image-upload"
                  accept="image/*"
                  className="hidden"
                  onChange={handleImageUpload}
                />
                <label
                  htmlFor="image-upload"
                  className="p-2 rounded-lg flex items-center text-gray-400 hover:text-[#00FFFF] cursor-pointer transition-colors"
                >
                  <Image size={20} />
                </label>
              </div>
              <button
                className="p-2 rounded-lg flex items-center text-gray-400 hover:text-[#00FFFF] transition-colors"
                onClick={() => setShowSkillSelector(!showSkillSelector)}
              >
                <Tag size={20} />
              </button>
              <button
                className="p-2 rounded-lg flex items-center text-gray-400 hover:text-[#00FFFF] transition-colors"
              >
                <Paperclip size={20} />
              </button>
            </div>
            <Button
              className="bg-[#00FFFF] text-black hover:bg-[#00FFFF]/90 flex items-center gap-2"
              onClick={handleSubmit}
              disabled={createPostMutation.isPending}
            >
              {createPostMutation.isPending ? (
                <span className="flex items-center gap-2">
                  <svg className="animate-spin h-5 w-5" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Publishing...
                </span>
              ) : (
                <>
                  <Send size={18} />
                  Publish
                </>
              )}
            </Button>
          </div>
        </Card>
        
        <div className="mt-8">
          <Card className="p-6 bg-[#1A1A1A] border-gray-800">
            <div className="flex items-center mb-4">
              <UploadCloud size={24} className="text-[#00FFFF] mr-3" />
              <h2 className="text-xl font-semibold text-white">Post Guidelines</h2>
            </div>
            <ul className="space-y-2 text-gray-300">
              <li className="flex items-center">
                <span className="w-1.5 h-1.5 rounded-full bg-[#00FFFF] mr-2"></span>
                Share knowledge, tutorials, or industry insights
              </li>
              <li className="flex items-center">
                <span className="w-1.5 h-1.5 rounded-full bg-[#00FFFF] mr-2"></span>
                Ask questions or seek collaboration on projects
              </li>
              <li className="flex items-center">
                <span className="w-1.5 h-1.5 rounded-full bg-[#00FFFF] mr-2"></span>
                Add relevant skills to reach the right audience
              </li>
              <li className="flex items-center">
                <span className="w-1.5 h-1.5 rounded-full bg-[#00FFFF] mr-2"></span>
                Be respectful and constructive in your content
              </li>
            </ul>
          </Card>
        </div>
      </div>
    </MainLayout>
  );
}