import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { z } from "zod";
import { motion } from "framer-motion";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { SkillBadge } from "@/components/ui/skill-badge";
import { MainLayout } from "@/components/layout/main-layout";
import { UserAvatar } from "@/components/user/user-avatar";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { User } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Loader2, User as UserIcon, Lock, Bell, Shield, CreditCard } from "lucide-react";

// Available skills for selection
const availableSkills = [
  "Web Dev", "UI/UX", "AI/ML", "Data Science", 
  "Mobile Dev", "DevOps", "Cybersecurity", "Game Dev",
  "Blockchain", "Cloud", "Backend", "Frontend"
];

// Form schema for profile settings
const profileFormSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  username: z.string().min(3, "Username must be at least 3 characters"),
  email: z.string().email("Invalid email address"),
  bio: z.string().optional(),
});

type ProfileFormValues = z.infer<typeof profileFormSchema>;

export default function Settings() {
  const { user, logoutMutation } = useAuth();
  const { toast } = useToast();
  const [selectedSkills, setSelectedSkills] = useState<string[]>(user?.skills || []);
  
  // Update profile mutation
  const updateProfileMutation = useMutation({
    mutationFn: async (data: Partial<User>) => {
      const res = await apiRequest("PUT", `/api/users/${user?.id}`, data);
      return res.json();
    },
    onSuccess: (updatedUser) => {
      queryClient.setQueryData(["/api/user"], updatedUser);
      toast({
        title: "Profile updated",
        description: "Your profile has been updated successfully!",
      });
    },
    onError: (error) => {
      toast({
        title: "Update failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Form for profile settings
  const form = useForm<ProfileFormValues>({
    resolver: zodResolver(profileFormSchema),
    defaultValues: {
      firstName: user?.firstName || "",
      lastName: user?.lastName || "",
      username: user?.username || "",
      email: user?.email || "",
      bio: user?.bio || "",
    },
  });

  // Toggle selected skill
  const toggleSkill = (skill: string) => {
    if (selectedSkills.includes(skill)) {
      setSelectedSkills(selectedSkills.filter(s => s !== skill));
    } else {
      setSelectedSkills([...selectedSkills, skill]);
    }
  };

  // Handle form submission
  const onSubmit = (values: ProfileFormValues) => {
    updateProfileMutation.mutate({
      ...values,
      skills: selectedSkills
    });
  };

  // Handle logout
  const handleLogout = () => {
    logoutMutation.mutate();
  };

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.3 }
    }
  };

  if (!user) {
    return null; // Protected route should handle this
  }

  return (
    <MainLayout>
      <div className="max-w-screen-xl mx-auto">
        <motion.div
          initial="hidden"
          animate="visible"
          variants={containerVariants}
        >
          <motion.div variants={itemVariants} className="mb-8">
            <h1 className="font-poppins font-bold text-3xl mb-4 text-white">Settings</h1>
            <p className="text-gray-300">
              Manage your account settings and preferences
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Sidebar */}
            <motion.div variants={itemVariants} className="lg:col-span-1">
              <div className="bg-[#1A1A1A] bg-opacity-25 backdrop-blur-md rounded-3xl p-6 border border-gray-800 sticky top-20">
                <div className="flex items-center space-x-3 mb-6 pb-6 border-b border-gray-800">
                  <UserAvatar user={user} size="lg" />
                  <div>
                    <h3 className="font-medium text-white">{user.firstName} {user.lastName}</h3>
                    <p className="text-gray-400">@{user.username}</p>
                  </div>
                </div>
                
                <nav className="space-y-1">
                  <a 
                    href="#profile" 
                    className="flex items-center space-x-3 px-4 py-3 rounded-xl bg-[#131926] text-[#00FFFF] transition-colors"
                  >
                    <UserIcon size={18} />
                    <span>Profile</span>
                  </a>
                  <a 
                    href="#security" 
                    className="flex items-center space-x-3 px-4 py-3 rounded-xl text-gray-300 hover:bg-[#131926] hover:text-white transition-colors"
                  >
                    <Lock size={18} />
                    <span>Security</span>
                  </a>
                  <a 
                    href="#notifications" 
                    className="flex items-center space-x-3 px-4 py-3 rounded-xl text-gray-300 hover:bg-[#131926] hover:text-white transition-colors"
                  >
                    <Bell size={18} />
                    <span>Notifications</span>
                  </a>
                  <a 
                    href="#privacy" 
                    className="flex items-center space-x-3 px-4 py-3 rounded-xl text-gray-300 hover:bg-[#131926] hover:text-white transition-colors"
                  >
                    <Shield size={18} />
                    <span>Privacy</span>
                  </a>
                  <a 
                    href="#billing" 
                    className="flex items-center space-x-3 px-4 py-3 rounded-xl text-gray-300 hover:bg-[#131926] hover:text-white transition-colors"
                  >
                    <CreditCard size={18} />
                    <span>Billing</span>
                  </a>
                </nav>

                <div className="mt-6 pt-6 border-t border-gray-800">
                  <button 
                    className="w-full px-4 py-3 rounded-xl bg-red-500 bg-opacity-10 text-red-500 hover:bg-opacity-20 transition-colors"
                    onClick={handleLogout}
                  >
                    Logout
                  </button>
                </div>
              </div>
            </motion.div>

            {/* Main Content */}
            <motion.div variants={itemVariants} className="lg:col-span-3">
              <Tabs defaultValue="account" className="w-full">
                <TabsList className="bg-[#131926] border border-gray-800 p-1 mb-6">
                  <TabsTrigger
                    value="account"
                    className="data-[state=active]:bg-[#00FFFF] data-[state=active]:text-black"
                  >
                    Account
                  </TabsTrigger>
                  <TabsTrigger
                    value="skills"
                    className="data-[state=active]:bg-[#00FFFF] data-[state=active]:text-black"
                  >
                    Skills & Expertise
                  </TabsTrigger>
                  <TabsTrigger
                    value="preferences"
                    className="data-[state=active]:bg-[#00FFFF] data-[state=active]:text-black"
                  >
                    Preferences
                  </TabsTrigger>
                </TabsList>

                {/* Account Settings Tab */}
                <TabsContent value="account">
                  <div className="bg-[#1A1A1A] bg-opacity-25 backdrop-blur-md rounded-3xl p-6 border border-gray-800">
                    <h2 className="text-xl font-semibold mb-6">Account Information</h2>
                    
                    <Form {...form}>
                      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <FormField
                            control={form.control}
                            name="firstName"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-white">First Name</FormLabel>
                                <FormControl>
                                  <Input
                                    placeholder="Your first name"
                                    className="bg-[#131926] border-gray-700 focus:border-[#00FFFF] text-white"
                                    {...field}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="lastName"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-white">Last Name</FormLabel>
                                <FormControl>
                                  <Input
                                    placeholder="Your last name"
                                    className="bg-[#131926] border-gray-700 focus:border-[#00FFFF] text-white"
                                    {...field}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <FormField
                          control={form.control}
                          name="username"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-white">Username</FormLabel>
                              <FormControl>
                                <Input
                                  placeholder="Your username"
                                  className="bg-[#131926] border-gray-700 focus:border-[#00FFFF] text-white"
                                  {...field}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="email"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-white">Email</FormLabel>
                              <FormControl>
                                <Input
                                  type="email"
                                  placeholder="Your email address"
                                  className="bg-[#131926] border-gray-700 focus:border-[#00FFFF] text-white"
                                  {...field}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="bio"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-white">Bio</FormLabel>
                              <FormControl>
                                <Textarea
                                  placeholder="Tell us about yourself..."
                                  className="bg-[#131926] border-gray-700 focus:border-[#00FFFF] text-white resize-none"
                                  rows={4}
                                  {...field}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="pt-4">
                          <Button
                            type="submit"
                            className="px-8 py-2 rounded-xl bg-[#00FFFF] text-black font-medium hover:opacity-90 transition-opacity"
                            disabled={updateProfileMutation.isPending}
                          >
                            {updateProfileMutation.isPending ? (
                              <><Loader2 className="h-4 w-4 animate-spin mr-2" /> Updating...</>
                            ) : (
                              'Save Changes'
                            )}
                          </Button>
                        </div>
                      </form>
                    </Form>
                  </div>
                </TabsContent>
                
                {/* Skills Tab */}
                <TabsContent value="skills">
                  <div className="bg-[#1A1A1A] bg-opacity-25 backdrop-blur-md rounded-3xl p-6 border border-gray-800">
                    <h2 className="text-xl font-semibold mb-2">Skills & Expertise</h2>
                    <p className="text-gray-400 mb-6">
                      Select the skills that best represent your expertise. These will be visible on your profile and help connect you with relevant opportunities.
                    </p>
                    
                    <div className="mb-6">
                      <h3 className="font-medium mb-3 text-white">Your skills</h3>
                      <div className="flex flex-wrap gap-2 mb-8">
                        {availableSkills.map((skill) => (
                          <SkillBadge
                            key={skill}
                            skill={skill}
                            selected={selectedSkills.includes(skill)}
                            clickable
                            onSelectChange={() => toggleSkill(skill)}
                          />
                        ))}
                      </div>
                      
                      {selectedSkills.length === 0 && (
                        <p className="text-yellow-500 text-sm mb-6">
                          Please select at least one skill to save your profile.
                        </p>
                      )}
                      
                      <Button
                        className="px-8 py-2 rounded-xl bg-[#00FFFF] text-black font-medium hover:opacity-90 transition-opacity"
                        onClick={form.handleSubmit(onSubmit)}
                        disabled={updateProfileMutation.isPending || selectedSkills.length === 0}
                      >
                        {updateProfileMutation.isPending ? (
                          <><Loader2 className="h-4 w-4 animate-spin mr-2" /> Updating...</>
                        ) : (
                          'Save Skills'
                        )}
                      </Button>
                    </div>
                    
                    <div className="pt-6 border-t border-gray-800">
                      <h3 className="font-medium mb-3 text-white">Skill verification</h3>
                      <p className="text-gray-400 mb-4">
                        Verify your skills to increase credibility and visibility on the platform.
                      </p>
                      
                      <div className="bg-[#131926] rounded-xl p-4 border border-gray-700 mb-4">
                        <div className="flex justify-between items-center">
                          <div>
                            <h4 className="font-medium text-white">Skill Assessment</h4>
                            <p className="text-sm text-gray-400">
                              Take skill tests to showcase your proficiency
                            </p>
                          </div>
                          <Button
                            variant="outline"
                            className="border-[#00FFFF] text-[#00FFFF] hover:bg-[#00FFFF] hover:bg-opacity-10"
                          >
                            Take Test
                          </Button>
                        </div>
                      </div>
                      
                      <div className="bg-[#131926] rounded-xl p-4 border border-gray-700">
                        <div className="flex justify-between items-center">
                          <div>
                            <h4 className="font-medium text-white">Certification Upload</h4>
                            <p className="text-sm text-gray-400">
                              Upload certificates to verify your skills
                            </p>
                          </div>
                          <Button
                            variant="outline"
                            className="border-[#00FFFF] text-[#00FFFF] hover:bg-[#00FFFF] hover:bg-opacity-10"
                          >
                            Upload
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </TabsContent>
                
                {/* Preferences Tab */}
                <TabsContent value="preferences">
                  <div className="bg-[#1A1A1A] bg-opacity-25 backdrop-blur-md rounded-3xl p-6 border border-gray-800">
                    <h2 className="text-xl font-semibold mb-6">App Preferences</h2>
                    
                    <div className="space-y-6">
                      <div className="flex justify-between items-center pb-4 border-b border-gray-800">
                        <div>
                          <h3 className="font-medium text-white">Email Notifications</h3>
                          <p className="text-sm text-gray-400">
                            Receive email notifications for important updates
                          </p>
                        </div>
                        <Switch className="bg-gray-700 data-[state=checked]:bg-[#00FFFF]" />
                      </div>
                      
                      <div className="flex justify-between items-center pb-4 border-b border-gray-800">
                        <div>
                          <h3 className="font-medium text-white">Push Notifications</h3>
                          <p className="text-sm text-gray-400">
                            Receive push notifications on your device
                          </p>
                        </div>
                        <Switch className="bg-gray-700 data-[state=checked]:bg-[#00FFFF]" defaultChecked />
                      </div>
                      
                      <div className="flex justify-between items-center pb-4 border-b border-gray-800">
                        <div>
                          <h3 className="font-medium text-white">Profile Visibility</h3>
                          <p className="text-sm text-gray-400">
                            Make your profile visible to other users
                          </p>
                        </div>
                        <Switch className="bg-gray-700 data-[state=checked]:bg-[#00FFFF]" defaultChecked />
                      </div>
                      
                      <div className="flex justify-between items-center pb-4 border-b border-gray-800">
                        <div>
                          <h3 className="font-medium text-white">Dark Mode</h3>
                          <p className="text-sm text-gray-400">
                            Use dark theme throughout the app
                          </p>
                        </div>
                        <Switch className="bg-gray-700 data-[state=checked]:bg-[#00FFFF]" defaultChecked />
                      </div>
                      
                      <div className="flex justify-between items-center pb-4 border-b border-gray-800">
                        <div>
                          <h3 className="font-medium text-white">Auto-Play Videos</h3>
                          <p className="text-sm text-gray-400">
                            Automatically play videos in your feed
                          </p>
                        </div>
                        <Switch className="bg-gray-700 data-[state=checked]:bg-[#00FFFF]" />
                      </div>
                      
                      <div className="flex justify-between items-center">
                        <div>
                          <h3 className="font-medium text-white">Save Data Mode</h3>
                          <p className="text-sm text-gray-400">
                            Reduce data usage when using the app
                          </p>
                        </div>
                        <Switch className="bg-gray-700 data-[state=checked]:bg-[#00FFFF]" />
                      </div>
                      
                      <div className="pt-4">
                        <Button
                          className="px-8 py-2 rounded-xl bg-[#00FFFF] text-black font-medium hover:opacity-90 transition-opacity"
                        >
                          Save Preferences
                        </Button>
                      </div>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </MainLayout>
  );
}
