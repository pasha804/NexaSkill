import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Search, UserPlus, UserCheck, UserX } from "lucide-react";
import { MainLayout } from "@/components/layout/main-layout";
import { UserAvatar } from "@/components/user/user-avatar";
import { SkillBadge } from "@/components/ui/skill-badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useMutation } from "@tanstack/react-query";
import { User } from "@shared/schema";
import { Loader2 } from "lucide-react";

interface FriendWithStatus {
  user: User;
  status: string;
}

export default function Friends() {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");
  
  // Fetch friends data
  const {
    data: friends,
    isLoading: friendsLoading,
    error: friendsError
  } = useQuery<FriendWithStatus[]>({
    queryKey: ["/api/friends"],
  });

  // Send friend request
  const sendFriendRequestMutation = useMutation({
    mutationFn: async (userId: number) => {
      const res = await apiRequest("POST", `/api/friends/${userId}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/friends"] });
    }
  });

  // Update friend request status
  const updateFriendStatusMutation = useMutation({
    mutationFn: async ({ userId, status }: { userId: number; status: string }) => {
      const res = await apiRequest("PUT", `/api/friends/${userId}`, { status });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/friends"] });
    }
  });

  // Filter friends by search term and status
  const filterFriends = (friendsList: FriendWithStatus[] | undefined, status: string, searchTerm: string) => {
    if (!friendsList) return [];
    
    return friendsList.filter(friend => {
      const matchesStatus = friend.status === status;
      
      if (!searchTerm) return matchesStatus;
      
      const fullName = `${friend.user.firstName || ''} ${friend.user.lastName || ''}`.toLowerCase();
      const matchesSearch = (
        friend.user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
        fullName.includes(searchTerm.toLowerCase())
      );
      
      return matchesStatus && matchesSearch;
    });
  };

  // Get filtered lists
  const acceptedFriends = filterFriends(friends, "accepted", searchTerm);
  const pendingFriends = filterFriends(friends, "pending", searchTerm);
  const requestedFriends = friends?.filter(f => f.status === "requested");

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.3 }
    }
  };

  return (
    <MainLayout>
      <div className="max-w-screen-xl mx-auto">
        <div className="mb-8">
          <h1 className="font-poppins font-bold text-3xl mb-4 text-white">Friends</h1>
          <p className="text-gray-300 mb-6">
            Manage your connections, friend requests, and find new people to connect with
          </p>

          {/* Search bar */}
          <div className="relative mb-8 max-w-md">
            <input
              type="text"
              placeholder="Search friends..."
              className="w-full pl-10 pr-4 py-3 bg-[#131926] rounded-xl border border-gray-700 focus:border-[#00FFFF] focus:outline-none text-white"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
          </div>
        </div>

        {/* Tabs for friend sections */}
        <Tabs defaultValue="friends" className="w-full">
          <TabsList className="bg-[#131926] border border-gray-800 p-1 mb-6">
            <TabsTrigger
              value="friends"
              className="data-[state=active]:bg-[#00FFFF] data-[state=active]:text-black"
            >
              Friends
            </TabsTrigger>
            <TabsTrigger
              value="requests"
              className="data-[state=active]:bg-[#00FFFF] data-[state=active]:text-black"
            >
              Requests {pendingFriends?.length ? `(${pendingFriends.length})` : ""}
            </TabsTrigger>
            <TabsTrigger
              value="suggestions"
              className="data-[state=active]:bg-[#00FFFF] data-[state=active]:text-black"
            >
              Suggestions
            </TabsTrigger>
          </TabsList>

          {/* Friends Tab */}
          <TabsContent value="friends">
            {friendsLoading ? (
              <div className="flex justify-center py-12">
                <Loader2 className="h-10 w-10 animate-spin text-[#00FFFF]" />
              </div>
            ) : friendsError ? (
              <div className="text-center py-10 bg-[#1A1A1A] bg-opacity-25 backdrop-blur-md rounded-3xl p-6 border border-gray-800">
                <p className="text-red-400">Failed to load friends. Please try again later.</p>
              </div>
            ) : (
              <motion.div 
                className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
                variants={containerVariants}
                initial="hidden"
                animate="visible"
              >
                {acceptedFriends.length > 0 ? (
                  acceptedFriends.map((friend) => (
                    <motion.div
                      key={friend.user.id}
                      className="bg-[#1A1A1A] bg-opacity-25 backdrop-blur-md rounded-3xl p-6 border border-gray-800 hover:border-[#00FFFF] transition-colors"
                      style={{
                        backgroundImage: "linear-gradient(to bottom, rgba(26, 26, 26, 0.25), rgba(19, 25, 38, 0.25))",
                        borderColor: "rgba(255, 255, 255, 0.05)"
                      }}
                      variants={itemVariants}
                    >
                      <div className="flex items-start mb-4">
                        <UserAvatar user={friend.user} size="lg" className="mr-4" />
                        <div>
                          <h3 className="font-medium text-lg text-white">
                            {friend.user.firstName} {friend.user.lastName}
                          </h3>
                          <p className="text-gray-400">@{friend.user.username}</p>
                          
                          {friend.user.skills && friend.user.skills.length > 0 && (
                            <div className="flex flex-wrap gap-2 mt-2">
                              {friend.user.skills.slice(0, 2).map((skill, index) => (
                                <SkillBadge
                                  key={index}
                                  skill={skill}
                                  color={index % 3 === 0 ? "blue" : index % 3 === 1 ? "green" : "gold"}
                                />
                              ))}
                              {friend.user.skills.length > 2 && (
                                <span className="text-gray-400 text-sm">+{friend.user.skills.length - 2} more</span>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                      
                      <div className="flex space-x-2 mt-4">
                        <button className="flex-1 py-2 rounded-xl bg-[#00FFFF] text-black font-medium hover:opacity-90 transition-opacity">
                          Message
                        </button>
                        <button className="flex items-center justify-center p-2 rounded-xl border border-gray-700 hover:border-[#00FFFF] transition-colors">
                          <UserX size={18} className="text-gray-300" />
                        </button>
                      </div>
                    </motion.div>
                  ))
                ) : (
                  <div className="col-span-full text-center py-10 bg-[#1A1A1A] bg-opacity-25 backdrop-blur-md rounded-3xl p-6 border border-gray-800">
                    <p className="text-gray-400 mb-2">No friends found</p>
                    <p className="text-sm text-gray-500">
                      {searchTerm ? "Try a different search term" : "Send some friend requests to get started"}
                    </p>
                  </div>
                )}
              </motion.div>
            )}
          </TabsContent>

          {/* Requests Tab */}
          <TabsContent value="requests">
            {friendsLoading ? (
              <div className="flex justify-center py-12">
                <Loader2 className="h-10 w-10 animate-spin text-[#00FFFF]" />
              </div>
            ) : friendsError ? (
              <div className="text-center py-10 bg-[#1A1A1A] bg-opacity-25 backdrop-blur-md rounded-3xl p-6 border border-gray-800">
                <p className="text-red-400">Failed to load friend requests. Please try again later.</p>
              </div>
            ) : (
              <motion.div 
                className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
                variants={containerVariants}
                initial="hidden"
                animate="visible"
              >
                {pendingFriends.length > 0 ? (
                  pendingFriends.map((friend) => (
                    <motion.div
                      key={friend.user.id}
                      className="bg-[#1A1A1A] bg-opacity-25 backdrop-blur-md rounded-3xl p-6 border border-gray-800 hover:border-[#00FFFF] transition-colors"
                      style={{
                        backgroundImage: "linear-gradient(to bottom, rgba(26, 26, 26, 0.25), rgba(19, 25, 38, 0.25))",
                        borderColor: "rgba(255, 255, 255, 0.05)"
                      }}
                      variants={itemVariants}
                    >
                      <div className="flex items-start mb-4">
                        <UserAvatar user={friend.user} size="lg" className="mr-4" />
                        <div>
                          <h3 className="font-medium text-lg text-white">
                            {friend.user.firstName} {friend.user.lastName}
                          </h3>
                          <p className="text-gray-400">@{friend.user.username}</p>
                          
                          {friend.user.skills && friend.user.skills.length > 0 && (
                            <div className="flex flex-wrap gap-2 mt-2">
                              {friend.user.skills.slice(0, 2).map((skill, index) => (
                                <SkillBadge
                                  key={index}
                                  skill={skill}
                                  color={index % 3 === 0 ? "blue" : index % 3 === 1 ? "green" : "gold"}
                                />
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                      
                      <div className="flex space-x-2 mt-4">
                        <button 
                          className="flex-1 py-2 rounded-xl bg-[#00FFFF] text-black font-medium hover:opacity-90 transition-opacity flex items-center justify-center"
                          onClick={() => updateFriendStatusMutation.mutate({ userId: friend.user.id, status: "accepted" })}
                          disabled={updateFriendStatusMutation.isPending}
                        >
                          {updateFriendStatusMutation.isPending ? (
                            <Loader2 className="h-4 w-4 animate-spin mr-2" />
                          ) : (
                            <UserCheck size={18} className="mr-2" />
                          )}
                          Accept
                        </button>
                        <button 
                          className="flex-1 py-2 rounded-xl border border-gray-700 text-gray-300 hover:border-red-500 hover:text-red-500 transition-colors flex items-center justify-center"
                          onClick={() => updateFriendStatusMutation.mutate({ userId: friend.user.id, status: "rejected" })}
                          disabled={updateFriendStatusMutation.isPending}
                        >
                          {updateFriendStatusMutation.isPending ? (
                            <Loader2 className="h-4 w-4 animate-spin mr-2" />
                          ) : (
                            <UserX size={18} className="mr-2" />
                          )}
                          Decline
                        </button>
                      </div>
                    </motion.div>
                  ))
                ) : (
                  <div className="col-span-full text-center py-10 bg-[#1A1A1A] bg-opacity-25 backdrop-blur-md rounded-3xl p-6 border border-gray-800">
                    <p className="text-gray-400 mb-2">No friend requests</p>
                    <p className="text-sm text-gray-500">
                      You don't have any pending friend requests at the moment
                    </p>
                  </div>
                )}
              </motion.div>
            )}
          </TabsContent>

          {/* Suggestions Tab */}
          <TabsContent value="suggestions">
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
              {/* Mock suggestions - would be replaced with actual API data */}
              {[1, 2, 3, 4, 5, 6].map((id) => (
                <motion.div
                  key={id}
                  className="bg-[#1A1A1A] bg-opacity-25 backdrop-blur-md rounded-3xl p-6 border border-gray-800 hover:border-[#00FFFF] transition-colors"
                  style={{
                    backgroundImage: "linear-gradient(to bottom, rgba(26, 26, 26, 0.25), rgba(19, 25, 38, 0.25))",
                    borderColor: "rgba(255, 255, 255, 0.05)"
                  }}
                  variants={itemVariants}
                >
                  <div className="flex items-start mb-4">
                    <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#00FFFF] to-[#131926] flex items-center justify-center text-white font-medium mr-4">
                      {String.fromCharCode(64 + id)}
                    </div>
                    <div>
                      <h3 className="font-medium text-lg text-white">
                        Suggested User {id}
                      </h3>
                      <p className="text-gray-400">@suggested{id}</p>
                      
                      <div className="flex flex-wrap gap-2 mt-2">
                        <SkillBadge skill="Web Dev" color="blue" />
                        <SkillBadge skill="UI/UX" color="green" />
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex space-x-2 mt-4">
                    <button 
                      className="flex-1 py-2 rounded-xl bg-[#00FFFF] text-black font-medium hover:opacity-90 transition-opacity flex items-center justify-center"
                      disabled={sendFriendRequestMutation.isPending}
                    >
                      <UserPlus size={18} className="mr-2" />
                      Connect
                    </button>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
}
