import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Video, Calendar, Clock, Plus, UserPlus, Link as LinkIcon, X } from "lucide-react";
import { MainLayout } from "@/components/layout/main-layout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { UserAvatar } from "@/components/user/user-avatar";
import { useAuth } from "@/hooks/use-auth";

// Temp meeting type until we create it in schema.ts
interface Meeting {
  id: number;
  title: string;
  description: string;
  date: string;
  time: string;
  duration: number;
  host: {
    id: number;
    name: string;
    avatar: string;
  };
  participants: {
    id: number;
    name: string;
    avatar: string;
  }[];
  skills: string[];
}

export default function Meetings() {
  const { user } = useAuth();
  const [newMeetingOpen, setNewMeetingOpen] = useState(false);
  const [inviteUserOpen, setInviteUserOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedDate, setSelectedDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  
  // Mock data for now - will be replaced with actual API calls
  const upcomingMeetings: Meeting[] = [
    {
      id: 1,
      title: "Project Collaboration Meeting",
      description: "Discuss the new features and plan the sprint",
      date: "2025-04-15",
      time: "10:00",
      duration: 60,
      host: {
        id: 1,
        name: "John Doe",
        avatar: ""
      },
      participants: [
        { id: 2, name: "Jane Smith", avatar: "" },
        { id: 3, name: "Alex Johnson", avatar: "" }
      ],
      skills: ["React", "Node.js", "Project Management"]
    },
    {
      id: 2,
      title: "UI/UX Design Review",
      description: "Review the latest designs and provide feedback",
      date: "2025-04-16",
      time: "14:00",
      duration: 45,
      host: {
        id: 2,
        name: "Jane Smith",
        avatar: ""
      },
      participants: [
        { id: 1, name: "John Doe", avatar: "" },
        { id: 4, name: "Sarah Williams", avatar: "" }
      ],
      skills: ["UI Design", "UX Design", "Figma"]
    }
  ];
  
  const pastMeetings: Meeting[] = [
    {
      id: 3,
      title: "Weekly Team Sync",
      description: "Regular team sync to discuss progress and blockers",
      date: "2025-04-08",
      time: "10:00",
      duration: 30,
      host: {
        id: 1,
        name: "John Doe",
        avatar: ""
      },
      participants: [
        { id: 2, name: "Jane Smith", avatar: "" },
        { id: 3, name: "Alex Johnson", avatar: "" },
        { id: 4, name: "Sarah Williams", avatar: "" }
      ],
      skills: ["Team Collaboration", "Project Management"]
    }
  ];
  
  // Function to format meeting time
  const formatMeetingTime = (date: string, time: string, duration: number) => {
    const meetingDate = new Date(`${date}T${time}`);
    const endTime = new Date(meetingDate.getTime() + duration * 60000);
    
    const formatTime = (date: Date) => {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    };
    
    return `${formatTime(meetingDate)} - ${formatTime(endTime)}`;
  };
  
  // Function to check if a meeting is happening now
  const isMeetingNow = (date: string, time: string, duration: number) => {
    const now = new Date();
    const meetingStart = new Date(`${date}T${time}`);
    const meetingEnd = new Date(meetingStart.getTime() + duration * 60000);
    
    return now >= meetingStart && now <= meetingEnd;
  };
  
  return (
    <MainLayout>
      <div className="container max-w-4xl mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-white">Meetings</h1>
          <Dialog open={newMeetingOpen} onOpenChange={setNewMeetingOpen}>
            <DialogTrigger asChild>
              <Button className="bg-[#00FFFF] text-black hover:bg-[#00FFFF]/90 flex items-center gap-2">
                <Plus size={18} />
                <span>New Meeting</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-[#1A1A1A] border-gray-800 text-white sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle className="text-white">Schedule a New Meeting</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Meeting Title</label>
                  <Input 
                    className="bg-[#131926] border-gray-700 text-white" 
                    placeholder="Enter meeting title" 
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Description</label>
                  <textarea 
                    className="w-full bg-[#131926] border border-gray-700 text-white rounded-md p-2" 
                    rows={3}
                    placeholder="Enter meeting description"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-300">Date</label>
                    <Input 
                      type="date" 
                      className="bg-[#131926] border-gray-700 text-white" 
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-300">Time</label>
                    <Input 
                      type="time" 
                      className="bg-[#131926] border-gray-700 text-white" 
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Duration (minutes)</label>
                  <Input 
                    type="number" 
                    min={15} 
                    step={15} 
                    defaultValue={30}
                    className="bg-[#131926] border-gray-700 text-white" 
                  />
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <label className="text-sm font-medium text-gray-300">Participants</label>
                    <Dialog open={inviteUserOpen} onOpenChange={setInviteUserOpen}>
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm" className="h-8 border-gray-700 text-[#00FFFF]">
                          <UserPlus size={16} className="mr-2" />
                          Add
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="bg-[#1A1A1A] border-gray-800 text-white sm:max-w-[500px]">
                        <DialogHeader>
                          <DialogTitle className="text-white">Invite Participants</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4 py-4">
                          <Input 
                            className="bg-[#131926] border-gray-700 text-white" 
                            placeholder="Search users..." 
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                          />
                          <div className="space-y-2 max-h-[300px] overflow-y-auto">
                            {/* User list will go here */}
                            <div className="flex items-center justify-between p-3 rounded-lg bg-[#131926] hover:bg-[#131926]/70 cursor-pointer">
                              <div className="flex items-center gap-3">
                                <div className="w-10 h-10 rounded-full bg-gray-700"></div>
                                <div>
                                  <p className="text-white font-medium">Jane Smith</p>
                                  <p className="text-sm text-gray-400">UI/UX Designer</p>
                                </div>
                              </div>
                              <Button variant="ghost" size="sm" className="text-[#00FFFF] h-8">
                                Add
                              </Button>
                            </div>
                            <div className="flex items-center justify-between p-3 rounded-lg bg-[#131926] hover:bg-[#131926]/70 cursor-pointer">
                              <div className="flex items-center gap-3">
                                <div className="w-10 h-10 rounded-full bg-gray-700"></div>
                                <div>
                                  <p className="text-white font-medium">Alex Johnson</p>
                                  <p className="text-sm text-gray-400">Frontend Developer</p>
                                </div>
                              </div>
                              <Button variant="ghost" size="sm" className="text-[#00FFFF] h-8">
                                Add
                              </Button>
                            </div>
                          </div>
                        </div>
                        <div className="flex justify-end gap-3">
                          <Button 
                            variant="outline" 
                            className="border-gray-700 text-white"
                            onClick={() => setInviteUserOpen(false)}
                          >
                            Cancel
                          </Button>
                          <Button 
                            className="bg-[#00FFFF] text-black hover:bg-[#00FFFF]/90"
                            onClick={() => setInviteUserOpen(false)}
                          >
                            Add Selected
                          </Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                  <div className="flex flex-wrap gap-2 bg-[#131926] rounded-md p-2 min-h-[50px]">
                    <div className="flex items-center gap-2 bg-[#2A2A2A] text-white px-2 py-1 rounded-md">
                      <div className="w-6 h-6 rounded-full bg-gray-700"></div>
                      <span className="text-sm">Jane Smith</span>
                      <button className="text-gray-400 hover:text-white">
                        <X size={14} />
                      </button>
                    </div>
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Skills (optional)</label>
                  <Input 
                    className="bg-[#131926] border-gray-700 text-white" 
                    placeholder="Add skills separated by commas" 
                  />
                </div>
                <div className="flex items-center space-x-2 mt-6">
                  <button className="flex items-center gap-2 border border-gray-700 rounded-md px-3 py-2 text-white text-sm hover:bg-[#131926]">
                    <LinkIcon size={16} />
                    <span>Generate Meeting Link</span>
                  </button>
                  <span className="text-gray-500 text-sm">or</span>
                  <button className="flex items-center gap-2 border border-gray-700 rounded-md px-3 py-2 text-white text-sm hover:bg-[#131926]">
                    <Calendar size={16} />
                    <span>Add to Calendar</span>
                  </button>
                </div>
              </div>
              <div className="flex justify-end gap-3">
                <Button 
                  variant="outline" 
                  className="border-gray-700 text-white"
                  onClick={() => setNewMeetingOpen(false)}
                >
                  Cancel
                </Button>
                <Button 
                  className="bg-[#00FFFF] text-black hover:bg-[#00FFFF]/90"
                  onClick={() => setNewMeetingOpen(false)}
                >
                  Schedule Meeting
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
        
        <Tabs defaultValue="upcoming" className="mb-8">
          <TabsList className="bg-[#1A1A1A] border border-gray-800 p-1">
            <TabsTrigger value="upcoming" className="data-[state=active]:bg-[#00FFFF] data-[state=active]:text-black">
              Upcoming
            </TabsTrigger>
            <TabsTrigger value="past" className="data-[state=active]:bg-[#00FFFF] data-[state=active]:text-black">
              Past
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="upcoming" className="mt-6">
            {upcomingMeetings.length === 0 ? (
              <Card className="p-8 text-center bg-[#1A1A1A] border-gray-800">
                <Video size={40} className="mx-auto text-gray-500 mb-4" />
                <h3 className="text-xl font-medium text-white mb-2">No upcoming meetings</h3>
                <p className="text-gray-400 max-w-md mx-auto mb-6">
                  You don't have any meetings scheduled. Create a new meeting to get started.
                </p>
                <Button
                  className="bg-[#00FFFF] text-black hover:bg-[#00FFFF]/90"
                  onClick={() => setNewMeetingOpen(true)}
                >
                  Schedule Meeting
                </Button>
              </Card>
            ) : (
              <div className="space-y-4">
                {upcomingMeetings.map((meeting) => (
                  <Card 
                    key={meeting.id}
                    className="p-5 bg-[#1A1A1A] border-gray-800 group hover:border-[#00FFFF]/50 transition-all"
                  >
                    <div className="flex items-start">
                      <div className="mr-4 p-3 rounded-full bg-[#131926]">
                        <Video className="text-[#00FFFF]" size={24} />
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between items-start">
                          <div>
                            <h3 className="text-xl font-semibold text-white group-hover:text-[#00FFFF] transition-colors">
                              {meeting.title}
                            </h3>
                            <p className="text-gray-400 mt-1">{meeting.description}</p>
                          </div>
                          <div className="ml-4">
                            {isMeetingNow(meeting.date, meeting.time, meeting.duration) ? (
                              <Button className="bg-green-600 hover:bg-green-700 text-white px-4">
                                Join Now
                              </Button>
                            ) : (
                              <Button variant="outline" className="border-gray-700 text-white hover:border-[#00FFFF] hover:text-[#00FFFF]">
                                View Details
                              </Button>
                            )}
                          </div>
                        </div>
                        
                        <div className="mt-4 flex flex-wrap items-center gap-4">
                          <div className="flex items-center text-sm text-gray-300">
                            <Calendar size={16} className="mr-2 text-gray-400" />
                            <span>{new Date(meeting.date).toLocaleDateString()}</span>
                          </div>
                          <div className="flex items-center text-sm text-gray-300">
                            <Clock size={16} className="mr-2 text-gray-400" />
                            <span>{formatMeetingTime(meeting.date, meeting.time, meeting.duration)}</span>
                          </div>
                        </div>
                        
                        <div className="mt-4 flex items-center justify-between">
                          <div className="flex -space-x-2">
                            {meeting.participants.slice(0, 3).map((participant, index) => (
                              <div 
                                key={participant.id} 
                                className="w-8 h-8 rounded-full bg-gray-600 border-2 border-[#1A1A1A] flex items-center justify-center text-xs text-white" 
                                title={participant.name}
                              >
                                {participant.name.charAt(0)}
                              </div>
                            ))}
                            {meeting.participants.length > 3 && (
                              <div className="w-8 h-8 rounded-full bg-[#131926] border-2 border-[#1A1A1A] flex items-center justify-center text-xs text-white">
                                +{meeting.participants.length - 3}
                              </div>
                            )}
                          </div>
                          
                          <div className="flex flex-wrap gap-2">
                            {meeting.skills.slice(0, 2).map((skill, index) => (
                              <span 
                                key={index}
                                className="px-2 py-1 text-xs rounded-md bg-[#131926] text-[#00FFFF]"
                              >
                                {skill}
                              </span>
                            ))}
                            {meeting.skills.length > 2 && (
                              <span className="px-2 py-1 text-xs rounded-md bg-[#131926] text-gray-400">
                                +{meeting.skills.length - 2}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="past" className="mt-6">
            {pastMeetings.length === 0 ? (
              <Card className="p-8 text-center bg-[#1A1A1A] border-gray-800">
                <Video size={40} className="mx-auto text-gray-500 mb-4" />
                <h3 className="text-xl font-medium text-white mb-2">No past meetings</h3>
                <p className="text-gray-400 max-w-md mx-auto">
                  Your past meetings will appear here
                </p>
              </Card>
            ) : (
              <div className="space-y-4">
                {pastMeetings.map((meeting) => (
                  <Card 
                    key={meeting.id}
                    className="p-5 bg-[#1A1A1A] border-gray-800 opacity-90"
                  >
                    <div className="flex items-start">
                      <div className="mr-4 p-3 rounded-full bg-[#131926]">
                        <Video className="text-gray-400" size={24} />
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between items-start">
                          <div>
                            <h3 className="text-xl font-semibold text-white">
                              {meeting.title}
                            </h3>
                            <p className="text-gray-400 mt-1">{meeting.description}</p>
                          </div>
                          <div className="ml-4">
                            <Button variant="outline" className="border-gray-700 text-white">
                              View Recording
                            </Button>
                          </div>
                        </div>
                        
                        <div className="mt-4 flex flex-wrap items-center gap-4">
                          <div className="flex items-center text-sm text-gray-300">
                            <Calendar size={16} className="mr-2 text-gray-400" />
                            <span>{new Date(meeting.date).toLocaleDateString()}</span>
                          </div>
                          <div className="flex items-center text-sm text-gray-300">
                            <Clock size={16} className="mr-2 text-gray-400" />
                            <span>{formatMeetingTime(meeting.date, meeting.time, meeting.duration)}</span>
                          </div>
                        </div>
                        
                        <div className="mt-4 flex items-center justify-between">
                          <div className="flex -space-x-2">
                            {meeting.participants.slice(0, 3).map((participant, index) => (
                              <div 
                                key={participant.id} 
                                className="w-8 h-8 rounded-full bg-gray-600 border-2 border-[#1A1A1A] flex items-center justify-center text-xs text-white" 
                                title={participant.name}
                              >
                                {participant.name.charAt(0)}
                              </div>
                            ))}
                            {meeting.participants.length > 3 && (
                              <div className="w-8 h-8 rounded-full bg-[#131926] border-2 border-[#1A1A1A] flex items-center justify-center text-xs text-white">
                                +{meeting.participants.length - 3}
                              </div>
                            )}
                          </div>
                          
                          <div className="flex flex-wrap gap-2">
                            {meeting.skills.slice(0, 2).map((skill, index) => (
                              <span 
                                key={index}
                                className="px-2 py-1 text-xs rounded-md bg-[#131926] text-gray-400"
                              >
                                {skill}
                              </span>
                            ))}
                            {meeting.skills.length > 2 && (
                              <span className="px-2 py-1 text-xs rounded-md bg-[#131926] text-gray-400">
                                +{meeting.skills.length - 2}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
}