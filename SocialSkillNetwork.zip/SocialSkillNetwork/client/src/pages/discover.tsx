import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Search, Filter } from "lucide-react";
import { motion } from "framer-motion";
import { MainLayout } from "@/components/layout/main-layout";
import { User } from "@shared/schema";
import { UserAvatar } from "@/components/user/user-avatar";
import { SkillBadge } from "@/components/ui/skill-badge";
import { Loader2 } from "lucide-react";

// Available skills for filtering
const availableSkills = [
  "Web Dev", "UI/UX", "AI/ML", "Data Science", 
  "Mobile Dev", "DevOps", "Cybersecurity", "Game Dev",
  "Blockchain", "Cloud", "Backend", "Frontend"
];

export default function Discover() {
  const [selectedSkill, setSelectedSkill] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");

  // Fetch users by skill
  const {
    data: users,
    isLoading,
    error
  } = useQuery<User[]>({
    queryKey: [selectedSkill ? `/api/skills/${selectedSkill}/users` : '/api/users'],
    enabled: true,
  });

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.3 }
    }
  };

  // Filter users by search term
  const filteredUsers = users?.filter(user => {
    if (!searchTerm) return true;
    
    const fullName = `${user.firstName || ''} ${user.lastName || ''}`.toLowerCase();
    return (
      user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
      fullName.includes(searchTerm.toLowerCase())
    );
  });

  return (
    <MainLayout>
      <div className="max-w-screen-xl mx-auto">
        <div className="mb-8">
          <h1 className="font-poppins font-bold text-3xl mb-4 text-white">Discover</h1>
          <p className="text-gray-300 mb-6">
            Find and connect with professionals based on skills, interests, and expertise
          </p>

          {/* Search and filter bar */}
          <div className="flex flex-col md:flex-row gap-4 mb-8">
            <div className="relative flex-1">
              <input
                type="text"
                placeholder="Search by name or username..."
                className="w-full pl-10 pr-4 py-3 bg-[#131926] rounded-xl border border-gray-700 focus:border-[#00FFFF] focus:outline-none text-white"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
            </div>
            
            <div className="relative">
              <button
                className="flex items-center space-x-2 px-4 py-3 bg-[#131926] rounded-xl border border-gray-700 hover:border-[#00FFFF] text-white"
              >
                <Filter size={18} />
                <span>Filters</span>
              </button>
            </div>
          </div>

          {/* Skills filter */}
          <div className="mb-8">
            <h2 className="font-medium mb-3 text-white">Filter by skill</h2>
            <div className="flex flex-wrap gap-2">
              <SkillBadge
                skill="All"
                color="blue"
                selected={selectedSkill === null}
                clickable
                onSelectChange={() => setSelectedSkill(null)}
              />
              {availableSkills.map((skill) => (
                <SkillBadge
                  key={skill}
                  skill={skill}
                  color={selectedSkill === skill ? "blue" : "blue"}
                  selected={selectedSkill === skill}
                  clickable
                  onSelectChange={() => setSelectedSkill(skill)}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Users grid */}
        {isLoading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="h-10 w-10 animate-spin text-[#00FFFF]" />
          </div>
        ) : error ? (
          <div className="text-center py-10 bg-[#1A1A1A] bg-opacity-25 backdrop-blur-md rounded-3xl p-6 border border-gray-800">
            <p className="text-red-400">Failed to load users. Please try again later.</p>
          </div>
        ) : (
          <motion.div 
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
          >
            {filteredUsers && filteredUsers.length > 0 ? (
              filteredUsers.map((user) => (
                <motion.div
                  key={user.id}
                  className="bg-[#1A1A1A] bg-opacity-25 backdrop-blur-md rounded-3xl p-6 border border-gray-800 hover:border-[#00FFFF] transition-colors"
                  style={{
                    backgroundImage: "linear-gradient(to bottom, rgba(26, 26, 26, 0.25), rgba(19, 25, 38, 0.25))",
                    borderColor: "rgba(255, 255, 255, 0.05)"
                  }}
                  variants={itemVariants}
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex space-x-3">
                      <UserAvatar user={user} size="lg" />
                      <div>
                        <h3 className="font-medium text-lg text-white">
                          {user.firstName} {user.lastName}
                        </h3>
                        <p className="text-gray-400">@{user.username}</p>
                      </div>
                    </div>
                  </div>
                  
                  {user.bio && (
                    <p className="text-gray-300 mb-4 line-clamp-2">{user.bio}</p>
                  )}
                  
                  <div className="flex flex-wrap gap-2 mb-4">
                    {user.skills && user.skills.map((skill, index) => (
                      <SkillBadge
                        key={index}
                        skill={skill}
                        color={index % 3 === 0 ? "blue" : index % 3 === 1 ? "green" : "gold"}
                      />
                    ))}
                  </div>
                  
                  <div className="flex space-x-2 mt-4">
                    <button className="flex-1 py-2 rounded-xl bg-[#00FFFF] text-black font-medium hover:opacity-90 transition-opacity">
                      Connect
                    </button>
                    <button className="flex-1 py-2 rounded-xl border border-[#00FFFF] text-[#00FFFF] hover:bg-[#00FFFF] hover:bg-opacity-10 transition-colors">
                      Message
                    </button>
                  </div>
                </motion.div>
              ))
            ) : (
              <div className="col-span-full text-center py-10 bg-[#1A1A1A] bg-opacity-25 backdrop-blur-md rounded-3xl p-6 border border-gray-800">
                <p className="text-gray-400 mb-2">No users found</p>
                <p className="text-sm text-gray-500">
                  {searchTerm ? "Try a different search term or filter" : "Try selecting a different skill"}
                </p>
              </div>
            )}
          </motion.div>
        )}
      </div>
    </MainLayout>
  );
}
