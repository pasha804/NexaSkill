import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Bell, CheckCircle2, Clock, UserPlus, MessageSquare, Star } from "lucide-react";
import { motion } from "framer-motion";
import { MainLayout } from "@/components/layout/main-layout";
import { UserAvatar } from "@/components/user/user-avatar";
import { useAuth } from "@/hooks/use-auth";
import { Card } from "@/components/ui/card";
import { Notification } from "@shared/schema";

export default function Notifications() {
  const { user } = useAuth();
  const [filter, setFilter] = useState<string>("all");
  
  // Fetch notifications
  const {
    data: notifications,
    isLoading,
    error
  } = useQuery<Notification[]>({
    queryKey: ["/api/notifications"],
  });
  
  // Filter notifications
  const filteredNotifications = notifications?.filter(notif => {
    if (filter === "all") return true;
    return notif.type === filter;
  }) || [];
  
  // Get icon for notification type
  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'friend_request':
        return <UserPlus className="text-blue-400" />;
      case 'friend_accepted':
        return <CheckCircle2 className="text-green-400" />;
      case 'message':
        return <MessageSquare className="text-violet-400" />;
      case 'skill_endorsed':
        return <Star className="text-yellow-400" />;
      default:
        return <Bell className="text-gray-400" />;
    }
  };
  
  // Format notification date
  const formatDate = (date: Date | string) => {
    const notifDate = date instanceof Date ? date : new Date(date);
    const now = new Date();
    const diffMs = now.getTime() - notifDate.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHours / 24);
    
    if (diffMins < 1) return 'just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    
    return notifDate.toLocaleDateString();
  };
  
  return (
    <MainLayout>
      <div className="container max-w-4xl mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-white">Notifications</h1>
          <div className="flex space-x-2">
            <button 
              className={`px-4 py-2 rounded-xl text-sm font-medium transition ${
                filter === "all" 
                  ? "bg-[#00FFFF] text-black" 
                  : "bg-[#1A1A1A] text-gray-300 hover:bg-[#131926]"
              }`}
              onClick={() => setFilter("all")}
            >
              All
            </button>
            <button 
              className={`px-4 py-2 rounded-xl text-sm font-medium transition ${
                filter === "friend_request" 
                  ? "bg-[#00FFFF] text-black" 
                  : "bg-[#1A1A1A] text-gray-300 hover:bg-[#131926]"
              }`}
              onClick={() => setFilter("friend_request")}
            >
              Friend Requests
            </button>
            <button 
              className={`px-4 py-2 rounded-xl text-sm font-medium transition ${
                filter === "message" 
                  ? "bg-[#00FFFF] text-black" 
                  : "bg-[#1A1A1A] text-gray-300 hover:bg-[#131926]"
              }`}
              onClick={() => setFilter("message")}
            >
              Messages
            </button>
          </div>
        </div>
        
        {isLoading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin h-10 w-10 border-4 border-[#00FFFF] border-t-transparent rounded-full"></div>
          </div>
        ) : error ? (
          <Card className="p-8 text-center bg-[#1A1A1A] border-red-500/30">
            <p className="text-red-400">Error loading notifications</p>
            <p className="text-gray-400 text-sm mt-2">Please try again later</p>
          </Card>
        ) : filteredNotifications.length === 0 ? (
          <Card className="p-8 text-center bg-[#1A1A1A] border-gray-800">
            <Bell size={40} className="mx-auto text-gray-500 mb-4" />
            <h3 className="text-xl font-medium text-white mb-2">No notifications yet</h3>
            <p className="text-gray-400 max-w-md mx-auto mb-0">
              {filter === "all" 
                ? "You're all caught up! Check back later for updates." 
                : "No notifications of this type. Try changing your filter."}
            </p>
          </Card>
        ) : (
          <div className="space-y-4">
            {filteredNotifications.map((notification) => (
              <Card 
                key={notification.id}
                className={`p-4 flex items-start bg-[#1A1A1A] border-gray-800 ${
                  !notification.read ? "border-l-4 border-l-[#00FFFF]" : ""
                }`}
              >
                <div className="rounded-full p-3 bg-[#131926] mr-4">
                  {getNotificationIcon(notification.type)}
                </div>
                <div className="flex-1">
                  <p className="text-white">{notification.content}</p>
                  <div className="flex items-center mt-2 text-sm text-gray-400">
                    <Clock size={14} className="mr-1" />
                    <span>{notification.createdAt && formatDate(notification.createdAt)}</span>
                  </div>
                </div>
                {!notification.read && (
                  <span className="h-2 w-2 rounded-full bg-[#00FFFF]"></span>
                )}
              </Card>
            ))}
          </div>
        )}
      </div>
    </MainLayout>
  );
}