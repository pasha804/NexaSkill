import { 
  User, InsertUser, Post, InsertPost, 
  Story, InsertStory, Message, InsertMessage,
  Friend, Notification, Comment, InsertComment,
  Like, InsertLike, Meeting, InsertMeeting,
  MeetingParticipant, InsertMeetingParticipant
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";
import connectPg from "connect-pg-simple";

// For MemStorage
const MemoryStore = createMemoryStore(session);

// For PostgreSQL sessions
const PostgresSessionStore = connectPg(session);

// Interface for storage operations
export interface IStorage {
  // Users
  getAllUsers(): Promise<User[]>;
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, data: Partial<User>): Promise<User | undefined>;
  getUsersBySkill(skill: string): Promise<User[]>;
  
  // Posts
  getAllPosts(): Promise<Post[]>;
  getPost(id: number): Promise<Post | undefined>;
  getUserPosts(userId: number): Promise<Post[]>;
  createPost(post: InsertPost & { userId: number }): Promise<Post>;
  
  // Stories
  getStories(): Promise<Story[]>;
  getUserStories(userId: number): Promise<Story[]>;
  createStory(story: InsertStory & { userId: number }): Promise<Story>;
  
  // Messages
  getMessages(userId1: number, userId2: number): Promise<Message[]>;
  createMessage(message: InsertMessage & { senderId: number }): Promise<Message>;
  
  // Friends
  getFriends(userId: number): Promise<{ user: User, status: string }[]>;
  addFriend(userId: number, friendId: number): Promise<Friend>;
  updateFriendStatus(userId: number, friendId: number, status: string): Promise<Friend | undefined>;
  
  // Notifications
  getNotifications(userId: number): Promise<Notification[]>;
  createNotification(notification: Omit<Notification, 'id' | 'createdAt'>): Promise<Notification>;
  markNotificationAsRead(id: number, userId: number): Promise<Notification | undefined>;
  
  // Comments
  getPostComments(postId: number): Promise<Comment[]>;
  createComment(comment: InsertComment & { userId: number }): Promise<Comment>;
  
  // Likes
  getLikes(postId?: number, commentId?: number): Promise<Like[]>;
  createLike(like: InsertLike & { userId: number }): Promise<Like>;
  deleteLike(likeId: number, userId: number): Promise<boolean>;
  
  // Meetings
  getAllMeetings(): Promise<Meeting[]>;
  getUserMeetings(userId: number): Promise<Meeting[]>;
  getMeeting(id: number): Promise<Meeting | undefined>;
  createMeeting(meeting: InsertMeeting & { hostId: number }): Promise<Meeting>;
  
  // Meeting participants
  getMeetingParticipants(meetingId: number): Promise<{ user: User; status: string }[]>;
  inviteToMeeting(meetingId: number, userId: number): Promise<MeetingParticipant>;
  updateParticipantStatus(meetingId: number, userId: number, status: string): Promise<MeetingParticipant | undefined>;
  
  // Session store
  sessionStore: session.Store;
}

// Memory storage implementation
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private posts: Map<number, Post>;
  private stories: Map<number, Story>;
  private messages: Map<number, Message>;
  private friends: Map<number, Friend>;
  private notifications: Map<number, Notification>;
  private comments: Map<number, Comment>;
  private likes: Map<number, Like>;
  private meetings: Map<number, Meeting>;
  private meetingParticipants: Map<number, MeetingParticipant>;
  
  sessionStore: session.Store;
  
  currentId: {
    user: number;
    post: number;
    story: number;
    message: number;
    friend: number;
    notification: number;
    comment: number;
    like: number;
    meeting: number;
    meetingParticipant: number;
  };

  constructor() {
    this.users = new Map();
    this.posts = new Map();
    this.stories = new Map();
    this.messages = new Map();
    this.friends = new Map();
    this.notifications = new Map();
    this.comments = new Map();
    this.likes = new Map();
    this.meetings = new Map();
    this.meetingParticipants = new Map();
    
    this.currentId = {
      user: 1,
      post: 1,
      story: 1,
      message: 1,
      friend: 1,
      notification: 1,
      comment: 1,
      like: 1,
      meeting: 1,
      meetingParticipant: 1
    };
    
    // Use PostgreSQL sessions for persistence while keeping data in memory
    this.sessionStore = process.env.DATABASE_URL
      ? new PostgresSessionStore({
          conObject: {
            connectionString: process.env.DATABASE_URL,
          },
          createTableIfMissing: true
        })
      : new MemoryStore({
          checkPeriod: 86400000 // 24 hours
        });
    
    // Add some demo users
    this.initializeDemoData();
  }
  
  private initializeDemoData() {
    // Will be populated by actual user registrations
  }

  // User methods
  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }
  
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase(),
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email?.toLowerCase() === email.toLowerCase(),
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId.user++;
    const now = new Date();
    
    // Process the fields to match the schema
    const user: User = { 
      id,
      username: insertUser.username,
      password: insertUser.password,
      firstName: insertUser.firstName || null,
      lastName: insertUser.lastName || null,
      email: insertUser.email || null,
      bio: insertUser.bio || null,
      profileImage: insertUser.profileImage || null,
      coverImage: insertUser.coverImage || null,
      skills: insertUser.skills || [],
      followers: 0,
      following: 0,
      isPremium: false,
      allowCrossSkillInvite: insertUser.allowCrossSkillInvite !== undefined ? insertUser.allowCrossSkillInvite : true,
      isPublicProfile: insertUser.isPublicProfile !== undefined ? insertUser.isPublicProfile : true,
      isSearchable: insertUser.isSearchable !== undefined ? insertUser.isSearchable : true,
      badges: insertUser.badges || [],
      location: insertUser.location || null,
      website: insertUser.website || null,
      socialLinks: insertUser.socialLinks || null,
      createdAt: now
    };
    
    this.users.set(id, user);
    return user;
  }
  
  async updateUser(id: number, data: Partial<User>): Promise<User | undefined> {
    const user = await this.getUser(id);
    
    if (!user) {
      return undefined;
    }
    
    const updatedUser = { ...user, ...data };
    this.users.set(id, updatedUser);
    
    return updatedUser;
  }
  
  async getUsersBySkill(skill: string): Promise<User[]> {
    return Array.from(this.users.values()).filter(user => 
      user.skills && user.skills.some(s => s.toLowerCase() === skill.toLowerCase())
    );
  }

  // Post methods
  async getAllPosts(): Promise<Post[]> {
    // Sort by newest first
    return Array.from(this.posts.values()).sort((a, b) => {
      const dateA = a.createdAt instanceof Date ? a.createdAt : new Date(0);
      const dateB = b.createdAt instanceof Date ? b.createdAt : new Date(0);
      return dateB.getTime() - dateA.getTime();
    });
  }
  
  async getPost(id: number): Promise<Post | undefined> {
    return this.posts.get(id);
  }
  
  async getUserPosts(userId: number): Promise<Post[]> {
    // Sort by newest first
    return Array.from(this.posts.values())
      .filter(post => post.userId === userId)
      .sort((a, b) => {
        const dateA = a.createdAt instanceof Date ? a.createdAt : new Date(0);
        const dateB = b.createdAt instanceof Date ? b.createdAt : new Date(0);
        return dateB.getTime() - dateA.getTime();
      });
  }
  
  async createPost(post: InsertPost & { userId: number }): Promise<Post> {
    const id = this.currentId.post++;
    const now = new Date();
    
    const newPost: Post = {
      id,
      userId: post.userId,
      content: post.content,
      image: post.image || null,
      skills: post.skills || null,
      likes: 0,
      comments: 0,
      shares: 0,
      createdAt: now
    };
    
    this.posts.set(id, newPost);
    return newPost;
  }

  // Story methods
  async getStories(): Promise<Story[]> {
    const now = new Date();
    
    // Filter stories that haven't expired
    return Array.from(this.stories.values())
      .filter(story => {
        const expiresAt = story.expiresAt instanceof Date 
          ? story.expiresAt 
          : story.expiresAt ? new Date(story.expiresAt) : null;
        return !expiresAt || expiresAt > now;
      })
      .sort((a, b) => {
        const dateA = a.createdAt instanceof Date ? a.createdAt : new Date(0);
        const dateB = b.createdAt instanceof Date ? b.createdAt : new Date(0);
        return dateB.getTime() - dateA.getTime();
      });
  }
  
  async getUserStories(userId: number): Promise<Story[]> {
    const now = new Date();
    
    return Array.from(this.stories.values())
      .filter(story => {
        const expiresAt = story.expiresAt instanceof Date 
          ? story.expiresAt 
          : story.expiresAt ? new Date(story.expiresAt) : null;
        return story.userId === userId && (!expiresAt || expiresAt > now);
      })
      .sort((a, b) => {
        const dateA = a.createdAt instanceof Date ? a.createdAt : new Date(0);
        const dateB = b.createdAt instanceof Date ? b.createdAt : new Date(0);
        return dateB.getTime() - dateA.getTime();
      });
  }
  
  async createStory(story: InsertStory & { userId: number }): Promise<Story> {
    const id = this.currentId.story++;
    const now = new Date();
    const expires = new Date(now);
    expires.setHours(expires.getHours() + 24); // Stories expire after 24 hours
    
    const newStory: Story = {
      id,
      userId: story.userId,
      content: story.content || null,
      image: story.image || null,
      createdAt: now,
      expiresAt: expires
    };
    
    this.stories.set(id, newStory);
    return newStory;
  }

  // Message methods
  async getMessages(userId1: number, userId2: number): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(message => 
        (message.senderId === userId1 && message.receiverId === userId2) ||
        (message.senderId === userId2 && message.receiverId === userId1)
      )
      .sort((a, b) => {
        const dateA = a.createdAt instanceof Date ? a.createdAt : new Date(0);
        const dateB = b.createdAt instanceof Date ? b.createdAt : new Date(0);
        return dateA.getTime() - dateB.getTime();
      });
  }
  
  async createMessage(message: InsertMessage & { senderId: number }): Promise<Message> {
    const id = this.currentId.message++;
    const now = new Date();
    
    const newMessage: Message = {
      id,
      senderId: message.senderId,
      receiverId: message.receiverId,
      content: message.content,
      createdAt: now,
      read: false
    };
    
    this.messages.set(id, newMessage);
    return newMessage;
  }

  // Friend methods
  async getFriends(userId: number): Promise<{ user: User, status: string }[]> {
    const friends = Array.from(this.friends.values())
      .filter(friend => friend.userId === userId || friend.friendId === userId);
    
    const result = await Promise.all(
      friends.map(async (friend) => {
        const otherId = friend.userId === userId ? friend.friendId : friend.userId;
        const user = await this.getUser(otherId);
        
        if (!user) {
          throw new Error(`User with ID ${otherId} not found`);
        }
        
        return {
          user,
          status: friend.status || 'pending'
        };
      })
    );
    
    return result;
  }
  
  async addFriend(userId: number, friendId: number): Promise<Friend> {
    // Check if friendship already exists
    const existingFriendship = Array.from(this.friends.values()).find(
      friend => 
        (friend.userId === userId && friend.friendId === friendId) ||
        (friend.userId === friendId && friend.friendId === userId)
    );
    
    if (existingFriendship) {
      return existingFriendship;
    }
    
    const id = this.currentId.friend++;
    const now = new Date();
    
    const newFriend: Friend = {
      id,
      userId,
      friendId,
      status: "pending",
      createdAt: now
    };
    
    this.friends.set(id, newFriend);
    
    // Create notification for friend request
    const user = await this.getUser(userId);
    if (user) {
      await this.createNotification({
        userId: friendId,
        type: "friend_request",
        content: `${user.firstName || user.username} sent you a friend request`,
        sourceId: userId,
        sourceType: "user",
        read: false
      });
    }
    
    return newFriend;
  }
  
  async updateFriendStatus(userId: number, friendId: number, status: string): Promise<Friend | undefined> {
    const friendship = Array.from(this.friends.values()).find(
      friend => 
        (friend.userId === userId && friend.friendId === friendId) ||
        (friend.userId === friendId && friend.friendId === userId)
    );
    
    if (!friendship) {
      return undefined;
    }
    
    friendship.status = status;
    this.friends.set(friendship.id, friendship);
    
    // Create notification for accepted friend request
    if (status === "accepted") {
      const user = await this.getUser(userId);
      if (user) {
        await this.createNotification({
          userId: friendId,
          type: "friend_accepted",
          content: `${user.firstName || user.username} accepted your friend request`,
          sourceId: userId,
          sourceType: "user",
          read: false
        });
      }
    }
    
    return friendship;
  }

  // Notification methods
  async getNotifications(userId: number): Promise<Notification[]> {
    return Array.from(this.notifications.values())
      .filter(notification => notification.userId === userId)
      .sort((a, b) => {
        const dateA = a.createdAt instanceof Date ? a.createdAt : new Date(0);
        const dateB = b.createdAt instanceof Date ? b.createdAt : new Date(0);
        return dateB.getTime() - dateA.getTime();
      });
  }
  
  async createNotification(notification: Omit<Notification, 'id' | 'createdAt'>): Promise<Notification> {
    const id = this.currentId.notification++;
    const now = new Date();
    
    const newNotification: Notification = {
      id,
      userId: notification.userId,
      type: notification.type,
      content: notification.content,
      sourceId: notification.sourceId || null,
      sourceType: notification.sourceType || null,
      read: notification.read || false,
      createdAt: now
    };
    
    this.notifications.set(id, newNotification);
    return newNotification;
  }
  
  async markNotificationAsRead(id: number, userId: number): Promise<Notification | undefined> {
    const notification = this.notifications.get(id);
    
    if (!notification || notification.userId !== userId) {
      return undefined;
    }
    
    notification.read = true;
    this.notifications.set(id, notification);
    
    return notification;
  }

  // Comment methods
  async getPostComments(postId: number): Promise<Comment[]> {
    return Array.from(this.comments.values())
      .filter(comment => comment.postId === postId)
      .sort((a, b) => {
        const dateA = a.createdAt instanceof Date ? a.createdAt : new Date(0);
        const dateB = b.createdAt instanceof Date ? b.createdAt : new Date(0);
        return dateA.getTime() - dateB.getTime(); // Oldest first
      });
  }
  
  async createComment(comment: InsertComment & { userId: number }): Promise<Comment> {
    const id = this.currentId.comment++;
    const now = new Date();
    
    const newComment: Comment = {
      id,
      userId: comment.userId,
      postId: comment.postId,
      content: comment.content,
      likes: 0,
      createdAt: now
    };
    
    this.comments.set(id, newComment);
    
    // Update the post's comment count
    const post = this.posts.get(comment.postId);
    if (post) {
      post.comments = (post.comments || 0) + 1;
      this.posts.set(post.id, post);
      
      // Create notification for post owner if it's not their own comment
      if (post.userId !== comment.userId) {
        const user = await this.getUser(comment.userId);
        if (user) {
          await this.createNotification({
            userId: post.userId,
            type: "comment",
            content: `${user.firstName || user.username} commented on your post`,
            sourceId: post.id,
            sourceType: "post",
            read: false
          });
        }
      }
    }
    
    return newComment;
  }
  
  // Like methods
  async getLikes(postId?: number, commentId?: number): Promise<Like[]> {
    return Array.from(this.likes.values())
      .filter(like => {
        if (postId) return like.postId === postId;
        if (commentId) return like.commentId === commentId;
        return true;
      })
      .sort((a, b) => {
        const dateA = a.createdAt instanceof Date ? a.createdAt : new Date(0);
        const dateB = b.createdAt instanceof Date ? b.createdAt : new Date(0);
        return dateB.getTime() - dateA.getTime();
      });
  }
  
  async createLike(like: InsertLike & { userId: number }): Promise<Like> {
    // Check if like already exists
    const existingLike = Array.from(this.likes.values()).find(
      l => l.userId === like.userId && 
           ((like.postId && l.postId === like.postId) || 
            (like.commentId && l.commentId === like.commentId))
    );
    
    if (existingLike) {
      return existingLike;
    }
    
    const id = this.currentId.like++;
    const now = new Date();
    
    const newLike: Like = {
      id,
      userId: like.userId,
      postId: like.postId || null,
      commentId: like.commentId || null,
      createdAt: now
    };
    
    this.likes.set(id, newLike);
    
    // Update like count on post or comment
    if (like.postId) {
      const post = this.posts.get(like.postId);
      if (post) {
        post.likes = (post.likes || 0) + 1;
        this.posts.set(post.id, post);
        
        // Create notification for post owner if it's not their own like
        if (post.userId !== like.userId) {
          const user = await this.getUser(like.userId);
          if (user) {
            await this.createNotification({
              userId: post.userId,
              type: "like_post",
              content: `${user.firstName || user.username} liked your post`,
              sourceId: post.id,
              sourceType: "post",
              read: false
            });
          }
        }
      }
    } else if (like.commentId) {
      const comment = this.comments.get(like.commentId);
      if (comment) {
        comment.likes++;
        this.comments.set(comment.id, comment);
        
        // Create notification for comment owner if it's not their own like
        if (comment.userId !== like.userId) {
          const user = await this.getUser(like.userId);
          if (user) {
            await this.createNotification({
              userId: comment.userId,
              type: "like_comment",
              content: `${user.firstName || user.username} liked your comment`,
              sourceId: comment.id,
              sourceType: "comment",
              read: false
            });
          }
        }
      }
    }
    
    return newLike;
  }
  
  async deleteLike(likeId: number, userId: number): Promise<boolean> {
    const like = this.likes.get(likeId);
    
    if (!like || like.userId !== userId) {
      return false;
    }
    
    // Update like count on post or comment
    if (like.postId) {
      const post = this.posts.get(like.postId);
      if (post && post.likes > 0) {
        post.likes--;
        this.posts.set(post.id, post);
      }
    } else if (like.commentId) {
      const comment = this.comments.get(like.commentId);
      if (comment && comment.likes > 0) {
        comment.likes--;
        this.comments.set(comment.id, comment);
      }
    }
    
    this.likes.delete(likeId);
    return true;
  }

  // Meeting methods
  async getAllMeetings(): Promise<Meeting[]> {
    return Array.from(this.meetings.values())
      .sort((a, b) => {
        const dateA = a.date instanceof Date ? a.date : new Date(a.date || 0);
        const dateB = b.date instanceof Date ? b.date : new Date(b.date || 0);
        return dateA.getTime() - dateB.getTime(); // Upcoming first
      });
  }
  
  async getUserMeetings(userId: number): Promise<Meeting[]> {
    // Get meetings where user is the host
    const hostedMeetings = Array.from(this.meetings.values())
      .filter(meeting => meeting.hostId === userId);
    
    // Get meetings where user is a participant
    const participatedMeetings = await this.getMeetingsAsParticipant(userId);
    
    // Combine and sort
    return [...hostedMeetings, ...participatedMeetings]
      .sort((a, b) => {
        const dateA = a.date instanceof Date ? a.date : new Date(a.date || 0);
        const dateB = b.date instanceof Date ? b.date : new Date(b.date || 0);
        return dateA.getTime() - dateB.getTime(); // Upcoming first
      });
  }
  
  private async getMeetingsAsParticipant(userId: number): Promise<Meeting[]> {
    const participations = Array.from(this.meetingParticipants.values())
      .filter(mp => mp.userId === userId);
    
    const meetings: Meeting[] = [];
    for (const participation of participations) {
      const meeting = this.meetings.get(participation.meetingId);
      if (meeting) {
        meetings.push(meeting);
      }
    }
    
    return meetings;
  }
  
  async getMeeting(id: number): Promise<Meeting | undefined> {
    return this.meetings.get(id);
  }
  
  async createMeeting(meeting: InsertMeeting & { hostId: number }): Promise<Meeting> {
    const id = this.currentId.meeting++;
    const now = new Date();
    
    const newMeeting: Meeting = {
      id,
      title: meeting.title,
      description: meeting.description || null,
      date: meeting.date,
      time: meeting.time || null,
      duration: meeting.duration || null,
      location: meeting.location || null,
      isOnline: meeting.isOnline || false,
      meetingLink: meeting.meetingLink || null,
      maxParticipants: meeting.maxParticipants || null,
      requiredSkills: meeting.requiredSkills || null,
      hostId: meeting.hostId,
      createdAt: now
    };
    
    this.meetings.set(id, newMeeting);
    return newMeeting;
  }
  
  // Meeting participant methods
  async getMeetingParticipants(meetingId: number): Promise<{ user: User; status: string }[]> {
    const participants = Array.from(this.meetingParticipants.values())
      .filter(mp => mp.meetingId === meetingId);
    
    const result = await Promise.all(
      participants.map(async (mp) => {
        const user = await this.getUser(mp.userId);
        
        if (!user) {
          throw new Error(`User with ID ${mp.userId} not found`);
        }
        
        return {
          user,
          status: mp.status || 'pending'
        };
      })
    );
    
    return result;
  }
  
  async inviteToMeeting(meetingId: number, userId: number): Promise<MeetingParticipant> {
    // Check if invitation already exists
    const existingInvitation = Array.from(this.meetingParticipants.values()).find(
      mp => mp.meetingId === meetingId && mp.userId === userId
    );
    
    if (existingInvitation) {
      return existingInvitation;
    }
    
    const id = this.currentId.meetingParticipant++;
    const now = new Date();
    
    const newParticipant: MeetingParticipant = {
      id,
      meetingId,
      userId,
      status: "invited",
      createdAt: now
    };
    
    this.meetingParticipants.set(id, newParticipant);
    
    // Create notification for the invited user
    const meeting = await this.getMeeting(meetingId);
    if (meeting) {
      const host = await this.getUser(meeting.hostId);
      if (host) {
        await this.createNotification({
          userId,
          type: "meeting_invite",
          content: `${host.firstName || host.username} invited you to a meeting: ${meeting.title}`,
          sourceId: meetingId,
          sourceType: "meeting",
          read: false
        });
      }
    }
    
    return newParticipant;
  }
  
  async updateParticipantStatus(meetingId: number, userId: number, status: string): Promise<MeetingParticipant | undefined> {
    const participation = Array.from(this.meetingParticipants.values()).find(
      mp => mp.meetingId === meetingId && mp.userId === userId
    );
    
    if (!participation) {
      return undefined;
    }
    
    participation.status = status;
    this.meetingParticipants.set(participation.id, participation);
    
    // Create notification for meeting host if the user accepts
    if (status === "accepted") {
      const meeting = await this.getMeeting(meetingId);
      if (meeting) {
        const user = await this.getUser(userId);
        if (user) {
          await this.createNotification({
            userId: meeting.hostId,
            type: "meeting_accepted",
            content: `${user.firstName || user.username} accepted your meeting invitation`,
            sourceId: meetingId,
            sourceType: "meeting",
            read: false
          });
        }
      }
    }
    
    return participation;
  }
}

// Export the storage implementation
export const storage = new MemStorage();