import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  firstName: text("first_name"),
  lastName: text("last_name"),
  email: text("email").unique(),
  bio: text("bio"),
  profileImage: text("profile_image"),
  coverImage: text("cover_image"),
  skills: text("skills").array(),
  followers: integer("followers").default(0),
  following: integer("following").default(0),
  isPremium: boolean("is_premium").default(false),
  allowCrossSkillInvite: boolean("allow_cross_skill_invite").default(true),
  isPublicProfile: boolean("is_public_profile").default(true),
  isSearchable: boolean("is_searchable").default(true),
  badges: text("badges").array(),
  location: text("location"),
  website: text("website"),
  socialLinks: jsonb("social_links"),
  createdAt: timestamp("created_at").defaultNow()
});

export const posts = pgTable("posts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  content: text("content").notNull(),
  image: text("image"),
  skills: text("skills").array(),
  likes: integer("likes").default(0),
  comments: integer("comments").default(0),
  shares: integer("shares").default(0),
  createdAt: timestamp("created_at").defaultNow()
});

export const stories = pgTable("stories", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  content: text("content"),
  image: text("image"),
  createdAt: timestamp("created_at").defaultNow(),
  expiresAt: timestamp("expires_at")
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  senderId: integer("sender_id").notNull(),
  receiverId: integer("receiver_id").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  read: boolean("read").default(false)
});

export const friends = pgTable("friends", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  friendId: integer("friend_id").notNull(),
  status: text("status").default("pending"), // pending, accepted, rejected
  createdAt: timestamp("created_at").defaultNow()
});

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  type: text("type").notNull(), // like, comment, follow, mention
  content: text("content").notNull(),
  sourceId: integer("source_id"), // ID of the post, comment, or user that triggered the notification
  sourceType: text("source_type"), // post, comment, user, friend_request, meeting
  read: boolean("read").default(false),
  createdAt: timestamp("created_at").defaultNow()
});

export const comments = pgTable("comments", {
  id: serial("id").primaryKey(),
  postId: integer("post_id").notNull(),
  userId: integer("user_id").notNull(),
  content: text("content").notNull(),
  likes: integer("likes").default(0),
  createdAt: timestamp("created_at").defaultNow()
});

export const likes = pgTable("likes", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  postId: integer("post_id"),
  commentId: integer("comment_id"),
  createdAt: timestamp("created_at").defaultNow()
});

export const meetings = pgTable("meetings", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  hostId: integer("host_id").notNull(),
  date: timestamp("date").notNull(),
  duration: integer("duration").default(60), // in minutes
  link: text("link"), // external meeting link (Zoom, Google Meet, etc.)
  meetingType: text("meeting_type").default("video"), // video, audio, external
  isPrivate: boolean("is_private").default(false), 
  skills: text("skills").array(),
  createdAt: timestamp("created_at").defaultNow()
});

export const meetingParticipants = pgTable("meeting_participants", {
  id: serial("id").primaryKey(),
  meetingId: integer("meeting_id").notNull(),
  userId: integer("user_id").notNull(),
  status: text("status").default("pending"), // pending, accepted, declined
  createdAt: timestamp("created_at").defaultNow()
});

// Schema for inserting users
export const insertUserSchema = createInsertSchema(users)
  .omit({ 
    id: true, 
    createdAt: true, 
    followers: true, 
    following: true,
    isPremium: true
  })
  .extend({
    confirmPassword: z.string(),
    firstName: z.string().optional(),
    lastName: z.string().optional(),
    email: z.string().email("Invalid email address").optional(),
    bio: z.string().optional(),
    profileImage: z.string().optional(),
    coverImage: z.string().optional(),
    skills: z.array(z.string()).min(1, "At least one skill is required"),
    badges: z.array(z.string()).optional(),
    location: z.string().optional(),
    website: z.string().optional(),
    socialLinks: z.any().optional(),
    allowCrossSkillInvite: z.boolean().default(true),
    isPublicProfile: z.boolean().default(true),
    isSearchable: z.boolean().default(true),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "Passwords don't match",
    path: ["confirmPassword"],
  });

// Schema for login
export const loginUserSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

// Schema for inserting posts
export const insertPostSchema = createInsertSchema(posts).omit({ 
  id: true, 
  userId: true, 
  likes: true, 
  comments: true, 
  shares: true, 
  createdAt: true 
});

// Schema for inserting stories
export const insertStorySchema = createInsertSchema(stories).omit({ 
  id: true, 
  userId: true, 
  createdAt: true, 
  expiresAt: true 
});

// Schema for inserting messages
export const insertMessageSchema = createInsertSchema(messages).omit({ 
  id: true, 
  createdAt: true, 
  read: true 
});

// Schema for inserting comments
export const insertCommentSchema = createInsertSchema(comments).omit({
  id: true,
  userId: true,
  likes: true,
  createdAt: true
});

// Schema for inserting likes
export const insertLikeSchema = createInsertSchema(likes).omit({
  id: true,
  userId: true,
  createdAt: true
});

// Schema for inserting meetings
export const insertMeetingSchema = createInsertSchema(meetings).omit({
  id: true,
  hostId: true,
  createdAt: true
});

// Schema for inserting meeting participants
export const insertMeetingParticipantSchema = createInsertSchema(meetingParticipants).omit({
  id: true,
  createdAt: true
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type LoginUser = z.infer<typeof loginUserSchema>;

export type Post = typeof posts.$inferSelect;
export type InsertPost = z.infer<typeof insertPostSchema>;

export type Story = typeof stories.$inferSelect;
export type InsertStory = z.infer<typeof insertStorySchema>;

export type Message = typeof messages.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;

export type Comment = typeof comments.$inferSelect;
export type InsertComment = z.infer<typeof insertCommentSchema>;

export type Like = typeof likes.$inferSelect;
export type InsertLike = z.infer<typeof insertLikeSchema>;

export type Meeting = typeof meetings.$inferSelect;
export type InsertMeeting = z.infer<typeof insertMeetingSchema>;

export type MeetingParticipant = typeof meetingParticipants.$inferSelect;
export type InsertMeetingParticipant = z.infer<typeof insertMeetingParticipantSchema>;

export type Friend = typeof friends.$inferSelect;
export type Notification = typeof notifications.$inferSelect;
