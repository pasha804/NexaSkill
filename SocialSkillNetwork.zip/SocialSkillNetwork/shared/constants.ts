
export const SKILL_CATEGORIES = {
  PROGRAMMING: [
    'JavaScript', 'Python', 'Java', 'C++', 'Ruby', 'Go', 'Rust',
    'TypeScript', 'PHP', 'Swift', 'Kotlin'
  ],
  FRAMEWORKS: [
    'React', 'Angular', 'Vue', 'Django', 'Flask', 'Spring',
    'Express', 'FastAPI', 'Laravel', 'Ruby on Rails'
  ],
  DESIGN: [
    'UI Design', 'UX Design', 'Graphic Design', 'Motion Design',
    'Web Design', 'Brand Design', 'Product Design'
  ],
  CLOUD: [
    'AWS', 'Azure', 'GCP', 'Docker', 'Kubernetes',
    'DevOps', 'CI/CD', 'Cloud Architecture'
  ],
  DATA: [
    'Data Science', 'Machine Learning', 'Deep Learning', 'NLP',
    'Computer Vision', 'Data Analysis', 'Big Data'
  ]
} as const;

export const ALL_SKILLS = Object.values(SKILL_CATEGORIES).flat();

export type Skill = typeof ALL_SKILLS[number];
